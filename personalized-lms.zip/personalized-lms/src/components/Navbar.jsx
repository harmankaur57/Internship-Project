import React from 'react';
import { 
  Brain, 
  Sparkles, 
  Flame, 
  User, 
  GraduationCap, 
  RotateCcw, 
  BookOpen, 
  Compass, 
  Zap, 
  BarChart2, 
  Lightbulb, 
  ShieldAlert
} from 'lucide-react';

export default function Navbar({ 
  currentRole, 
  activeTab, 
  setActiveTab, 
  activeStudent, 
  setActiveStudent, 
  students, 
  onResetData 
}) {
  const isInstructor = currentRole === 'instructor';

  return (
    <header 
      style={{
        position: 'sticky',
        top: 0,
        zIndex: 100,
        background: 'rgba(10, 15, 29, 0.85)',
        backdropFilter: 'blur(16px)',
        borderBottom: '1px solid var(--border-subtle)',
        padding: '12px 24px'
      }}
    >
      <div 
        style={{
          maxWidth: 1400,
          margin: '0 auto',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: 16
        }}
      >
        {/* Logo & Identity */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div 
            style={{
              width: 40,
              height: 40,
              borderRadius: 12,
              background: 'linear-gradient(135deg, #6366f1, #06b6d4)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 0 20px rgba(99, 102, 241, 0.5)'
            }}
          >
            <Brain size={22} color="#ffffff" />
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ fontWeight: 800, fontSize: '1.25rem', letterSpacing: '-0.02em' }} className="title-gradient">
                AdaptIQ
              </span>
              <span 
                className="badge" 
                style={{ 
                  background: 'rgba(99, 102, 241, 0.2)', 
                  color: '#818cf8', 
                  fontSize: '0.65rem',
                  padding: '2px 6px'
                }}
              >
                AI-LMS
              </span>
            </div>
            <p style={{ fontSize: '0.72rem', color: 'var(--text-dim)', marginTop: -2 }}>
              Personalized Adaptive Learning
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav style={{ display: 'flex', gap: 6, background: 'rgba(255, 255, 255, 0.04)', padding: 4, borderRadius: 12, border: '1px solid var(--border-subtle)' }}>
          {!isInstructor ? (
            <>
              <button 
                onClick={() => setActiveTab('dashboard')} 
                style={{
                  padding: '8px 14px',
                  borderRadius: 8,
                  fontSize: '0.85rem',
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  color: activeTab === 'dashboard' ? '#ffffff' : 'var(--text-muted)',
                  background: activeTab === 'dashboard' ? 'var(--accent-primary)' : 'transparent'
                }}
              >
                <Compass size={16} /> Dashboard
              </button>
              <button 
                onClick={() => setActiveTab('courses')} 
                style={{
                  padding: '8px 14px',
                  borderRadius: 8,
                  fontSize: '0.85rem',
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  color: activeTab === 'courses' ? '#ffffff' : 'var(--text-muted)',
                  background: activeTab === 'courses' ? 'var(--accent-primary)' : 'transparent'
                }}
              >
                <BookOpen size={16} /> Courses
              </button>
              <button 
                onClick={() => setActiveTab('quiz')} 
                style={{
                  padding: '8px 14px',
                  borderRadius: 8,
                  fontSize: '0.85rem',
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  color: activeTab === 'quiz' ? '#ffffff' : 'var(--text-muted)',
                  background: activeTab === 'quiz' ? 'var(--accent-primary)' : 'transparent'
                }}
              >
                <Zap size={16} /> Adaptive Quiz
              </button>
              <button 
                onClick={() => setActiveTab('analytics')} 
                style={{
                  padding: '8px 14px',
                  borderRadius: 8,
                  fontSize: '0.85rem',
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  color: activeTab === 'analytics' ? '#ffffff' : 'var(--text-muted)',
                  background: activeTab === 'analytics' ? 'var(--accent-primary)' : 'transparent'
                }}
              >
                <BarChart2 size={16} /> Progress
              </button>
              <button 
                onClick={() => setActiveTab('recommendations')} 
                style={{
                  padding: '8px 14px',
                  borderRadius: 8,
                  fontSize: '0.85rem',
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  color: activeTab === 'recommendations' ? '#ffffff' : 'var(--text-muted)',
                  background: activeTab === 'recommendations' ? 'var(--accent-primary)' : 'transparent'
                }}
              >
                <Lightbulb size={16} /> AI Path
              </button>
            </>
          ) : (
            <>
              <button 
                onClick={() => setActiveTab('instructor-cohort')} 
                style={{
                  padding: '8px 16px',
                  borderRadius: 8,
                  fontSize: '0.85rem',
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  color: activeTab === 'instructor-cohort' ? '#ffffff' : 'var(--text-muted)',
                  background: activeTab === 'instructor-cohort' ? 'var(--accent-primary)' : 'transparent'
                }}
              >
                <GraduationCap size={16} /> Class Cohort & Interventions
              </button>
              <button 
                onClick={() => setActiveTab('instructor-curriculum')} 
                style={{
                  padding: '8px 16px',
                  borderRadius: 8,
                  fontSize: '0.85rem',
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  color: activeTab === 'instructor-curriculum' ? '#ffffff' : 'var(--text-muted)',
                  background: activeTab === 'instructor-curriculum' ? 'var(--accent-primary)' : 'transparent'
                }}
              >
                <BookOpen size={16} /> Curriculum & Adaptive Question Bank
              </button>
            </>
          )}
        </nav>

        {/* User Persona & Role Switcher */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          {/* Streak Indicator (if student) */}
          {!isInstructor && activeStudent && (
            <div 
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                background: 'rgba(245, 158, 11, 0.1)',
                border: '1px solid rgba(245, 158, 11, 0.3)',
                padding: '6px 12px',
                borderRadius: 20
              }}
            >
              <Flame size={16} className="pulse-fire" color="#f59e0b" />
              <span style={{ fontSize: '0.82rem', fontWeight: 700, color: '#fbbf24' }}>
                {activeStudent.streakDays}d Streak
              </span>
            </div>
          )}

          {/* Persona Dropdown */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div 
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                background: 'rgba(255, 255, 255, 0.05)',
                border: '1px solid var(--border-subtle)',
                borderRadius: 12,
                padding: '4px 8px'
              }}
            >
              <User size={16} color="var(--text-dim)" />
              <select
                value={isInstructor ? 'instructor' : activeStudent?.id || ''}
                onChange={e => {
                  const val = e.target.value;
                  if (val === 'instructor') {
                    setActiveTab('instructor-cohort');
                  } else {
                    const st = students.find(s => s.id === val);
                    if (st) setActiveStudent(st);
                    if (isInstructor) setActiveTab('dashboard');
                  }
                }}
                style={{
                  background: 'transparent',
                  border: 'none',
                  fontSize: '0.85rem',
                  fontWeight: 600,
                  color: '#ffffff',
                  padding: '4px 6px',
                  cursor: 'pointer'
                }}
              >
                <optgroup label="Student Personas (Simulation)">
                  {students.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.engagementScore < 50 ? '⚠️ At-Risk' : `${s.overallMastery}% Mastery`})
                    </option>
                  ))}
                </optgroup>
                <optgroup label="Faculty / Admin">
                  <option value="instructor">Dr. Evelyn Vance (Instructor)</option>
                </optgroup>
              </select>
            </div>

            {/* Reset Button */}
            <button 
              onClick={onResetData} 
              title="Reset Demo Data"
              className="btn-secondary" 
              style={{ padding: '8px 10px', borderRadius: 10 }}
            >
              <RotateCcw size={15} />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
