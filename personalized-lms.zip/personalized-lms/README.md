# AdaptIQ - Personalized Learning Management System (LMS)

> A modern, web-enabled LMS that dynamically adapts curriculum, diagnostic assessments, and learning recommendations to individual student performance, pacing, and engagement patterns.

---

## 🌟 Problem Statement
Traditional Learning Management Systems (LMS) enforce a rigid, one-size-fits-all curriculum. Every student receives the exact same sequence of materials and identical static assessments, regardless of whether they are struggling with foundational prerequisites or bored by concepts they have already mastered. As a consequence:
1. **Struggling students** fall behind without timely diagnostic detection or automated remediation.
2. **Advanced students** experience disengagement and under-stimulation due to a lack of accelerated pathways.
3. **Instructors** lack granular, real-time insight into cohort bottlenecks and individual learning styles.

## 🎯 Objective
**AdaptIQ** solves this problem by integrating:
- **Dynamic Item Response Theory (IRT)** for adaptive quizzes.
- **Multi-Factor Pedagogical Recommendation Engine** that adjusts to concept mastery, active study velocity, and preferred learning modalities.
- **Engagement & Retention Analytics** to calculate time-on-task and identify drop-off risks early.
- **Instructor Command Center** for real-time cohort heatmaps, bottleneck discovery, and direct automated interventions.

---

## 🚀 Key Features

### 1. 📚 Course & Curriculum Management
- Structured multi-module curricula with progressive learning objectives.
- Interactive coding sandboxes and algorithmic simulators directly embedded inside lessons:
  - **Two-Pointer Convergence Simulator**: Visualizes $O(n)$ search space reduction.
  - **Call Stack & Activation Frame Simulator**: Demonstrates recursive unwinding and base-case triggers.
  - **Binary Search Tree (BST) Traversal Visualizer**: Demonstrates In-order, Pre-order, and Post-order traversals step-by-step.
- Real-time time-on-task session logging with completion verification.

### 2. ⚡ Adaptive Quizzes Engine (IRT-Calibrated)
- **Calibrated Entry Point**: Starts at the student's current baseline mastery (Easy, Medium, or Hard).
- **Dynamic Difficulty Ramping**:
  - Consecutive correct answers escalate difficulty tier (`Easy -> Medium -> Hard`) and boost mastery weight.
  - Incorrect answers immediately adapt downwards, unlocking remedial hints and diagnostic explanations.
- **Hint Penalty Logic**: Students can request pedagogical hints with calibrated score adjustments.
- **Diagnostic Session Reports**:
  - Visual trajectory graphs showing difficulty progression across questions.
  - Automated detection of **Mastered Concepts** vs. **Identified Knowledge Gaps**.
  - Real-time recalibration of the student's mastery matrix.

### 3. 📊 Engagement & Progress Tracking
- **Overall Mastery Index**: Weighted aggregate of 12+ concept competencies.
- **Learning Streak & Daily Goals**: Gamified retention mechanisms with daily time-on-task tracking.
- **Concept Competency Matrix**: Granular breakdowns categorized into *Advanced (>80%)*, *Proficient (65-80%)*, and *Developing (<65%)*.
- **Milestone Badges**: Awarded for consistency, streak milestones, and analytical problem-solving.

### 4. 🧠 Multi-Factor Recommendation Engine
The recommendation pipeline evaluates five pedagogical vectors:
1. **Remedial Targeting**: Automatically links to micro-lessons for the student's lowest-scoring concept tags.
2. **Honors Acceleration**: Unlocks hard-tier challenges when core competencies exceed 85%.
3. **Engagement Calibrator**: Suggests 5-minute low-friction interactive simulations if engagement falls below 50%.
4. **Streak Continuator**: Suggests timely lessons to keep learning streaks active.
5. **Modality Personalization**: Tailors recommendations to student learning styles (**Visual/Interactive**, **Hands-on Practical**, or **Theoretical/Conceptual**).

### 5. 🎓 Instructor Command Center
- **Cohort Health Overview**: Average class mastery, active engagement rate, and enrolled student distribution.
- **At-Risk Early Warning System**: Automatically flags disengaged students or those with failing retention.
- **Concept Bottleneck Heatmap**: Pinpoints questions and topics with the highest failure rates across the class.
- **Intervention Dispatcher**: Instructors can send targeted assignments, 1-on-1 office hour invites, or motivational nudges with one click.
- **Assessment & Course Authoring**: Add new courses, modules, and calibrated adaptive quiz items to the live bank.

---

## 🛠️ Technology Stack
- **Frontend**: React 19, Vite, Tailwind-compatible modern CSS variables, Lucide React icons.
- **Backend**: Node.js, Express REST API.
- **Architecture**: In-memory reactive state engine with persistent JSON fixtures and seamless client-side SPA routing.
- **Port Setup**: Server runs on port `5001` (serving both API endpoints and the compiled React production client).

---

## 🏃 Getting Started & Running Locally

### Prerequisites
- Node.js `v18+` or `v24+`
- npm (Use `npm.cmd` on Windows PowerShell if execution policies restrict `.ps1` scripts)

### Installation & Execution
```powershell
# Navigate to project directory
cd "C:\Users\Harman\.gemini\antigravity\scratch\personalized-lms"

# Install dependencies (already installed)
npm.cmd install

# Build the frontend assets
npm.cmd run build

# Start the full-stack server
node server/index.js
```

Open your browser at:
👉 **[http://localhost:5001](http://localhost:5001)**

---

## 👥 Demo Personas to Explore in the UI
Use the top-right persona switcher to test how the system dynamically personalizes:
1. **Alex Chen (Visual Learner)**: Balanced mastery (72%), 6-day streak. Recommends visual recursion simulators and tree traversals.
2. **Maria Garcia (High Achiever)**: Advanced mastery (89%), 14-day streak. Unlocks Hard-Tier Algorithmic Challenges and Machine Learning electives.
3. **Jordan Lee (At-Risk Learner)**: Struggling mastery (46%), low engagement (36%). Triggers 5-minute interactive micro-learning modules and instructor intervention flags.
4. **Dr. Evelyn Vance (Faculty)**: Unlocks the Instructor Command Center, cohort analytics, and curriculum authoring tools.
