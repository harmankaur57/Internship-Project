import React, { useState } from 'react';
import { BookOpen, Clock, Users, Star, ArrowRight, Zap, CheckCircle2 } from 'lucide-react';

export default function CourseCatalog({ 
  courses, 
  student, 
  onSelectCourse, 
  onStartQuiz 
}) {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = ['all', 'Computer Science', 'Web Development', 'Artificial Intelligence'];

  const filteredCourses = selectedCategory === 'all'
    ? courses
    : courses.filter(c => c.category === selectedCategory);

  return (
    <div style={{ maxWidth: 1300, margin: '0 auto', padding: '32px 24px' }}>
      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <h2 style={{ fontSize: '1.75rem', fontWeight: 800 }}>Course Catalog & Adaptive Curricula</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem', marginTop: 4 }}>
          Curated courses featuring interactive visual simulations and performance-adaptive assessment banks.
        </p>

        {/* Category Filter Pills */}
        <div style={{ display: 'flex', gap: 10, marginTop: 18, flexWrap: 'wrap' }}>
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              style={{
                padding: '8px 16px',
                borderRadius: 20,
                fontSize: '0.85rem',
                fontWeight: 600,
                background: selectedCategory === cat ? 'var(--accent-primary)' : 'rgba(255, 255, 255, 0.05)',
                color: selectedCategory === cat ? '#ffffff' : 'var(--text-muted)',
                border: selectedCategory === cat ? '1px solid var(--accent-primary)' : '1px solid var(--border-subtle)'
              }}
            >
              {cat === 'all' ? 'All Domains' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Courses Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: 24 }}>
        {filteredCourses.map(course => {
          const enrollment = student?.enrolledCourses?.find(e => e.courseId === course.id);
          const isEnrolled = Boolean(enrollment);
          const progress = enrollment?.progressPercent || 0;

          return (
            <div 
              key={course.id} 
              className="glass-panel glass-panel-interactive" 
              style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden' }}
            >
              {/* Image banner */}
              <div style={{ height: 160, position: 'relative', overflow: 'hidden' }}>
                <img 
                  src={course.thumbnail} 
                  alt={course.title} 
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }} 
                />
                <div 
                  style={{ 
                    position: 'absolute', 
                    top: 12, 
                    left: 12, 
                    display: 'flex', 
                    gap: 8 
                  }}
                >
                  <span className="badge badge-accent">{course.category}</span>
                  <span className="badge badge-medium">{course.level}</span>
                </div>
              </div>

              {/* Course body */}
              <div style={{ padding: 20, flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                <div>
                  <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: '#ffffff' }}>{course.title}</h3>
                  <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: 8, lineHeight: 1.5 }}>
                    {course.description}
                  </p>

                  <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginTop: 14, fontSize: '0.8rem', color: 'var(--text-dim)' }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                      <Clock size={14} /> {course.estimatedHours} hrs
                    </span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                      <Users size={14} /> {course.enrolledCount} learners
                    </span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 4, color: '#fbbf24' }}>
                      <Star size={14} fill="#fbbf24" /> {course.rating}
                    </span>
                  </div>
                </div>

                {/* Progress or Enroll footer */}
                <div style={{ marginTop: 20, paddingTop: 16, borderTop: '1px solid var(--border-subtle)' }}>
                  {isEnrolled ? (
                    <div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: 6 }}>
                        <span style={{ color: 'var(--text-dim)' }}>Your Mastery Progress</span>
                        <span style={{ fontWeight: 700, color: '#38bdf8' }}>{progress}%</span>
                      </div>
                      <div className="progress-track">
                        <div 
                          className="progress-fill" 
                          style={{ width: `${progress}%`, background: 'linear-gradient(90deg, #6366f1, #06b6d4)' }} 
                        />
                      </div>
                      <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
                        <button 
                          onClick={() => onSelectCourse(course.id)} 
                          className="btn-primary" 
                          style={{ flex: 1, padding: '10px 14px', fontSize: '0.85rem' }}
                        >
                          Study Lessons <ArrowRight size={15} />
                        </button>
                        <button 
                          onClick={() => onStartQuiz(course.id)} 
                          className="btn-secondary" 
                          title="Adaptive Quiz"
                          style={{ padding: '10px 14px' }}
                        >
                          <Zap size={16} color="#fbbf24" />
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button 
                      onClick={() => onSelectCourse(course.id)} 
                      className="btn-primary" 
                      style={{ width: '100%', padding: '10px 16px' }}
                    >
                      Enroll in Adaptive Track <ArrowRight size={16} />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
