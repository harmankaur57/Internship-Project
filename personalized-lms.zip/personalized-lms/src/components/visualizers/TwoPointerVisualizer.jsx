import React, { useState } from 'react';
import { ArrowDown, CheckCircle, RefreshCw, Play, RotateCcw } from 'lucide-react';

export default function TwoPointerVisualizer() {
  const [target, setTarget] = useState(14);
  const arr = [2, 4, 7, 9, 11, 13, 16, 20];
  const [left, setLeft] = useState(0);
  const [right, setRight] = useState(arr.length - 1);
  const [found, setFound] = useState(false);
  const [history, setHistory] = useState([
    "Initialized pointers: Left at index 0 (val 2), Right at index 7 (val 20)."
  ]);

  const currentSum = arr[left] + arr[right];

  const reset = () => {
    setLeft(0);
    setRight(arr.length - 1);
    setFound(false);
    setHistory(["Reset visualizer. Target sum is " + target]);
  };

  const stepNext = () => {
    if (found || left >= right) return;

    if (currentSum === target) {
      setFound(true);
      setHistory(prev => [
        `🎯 Target ${target} FOUND! arr[${left}] (${arr[left]}) + arr[${right}] (${arr[right]}) = ${target}`,
        ...prev
      ]);
      return;
    }

    if (currentSum < target) {
      const nextLeft = left + 1;
      setLeft(nextLeft);
      setHistory(prev => [
        `Sum (${currentSum}) < ${target}. Advanced Left pointer to index ${nextLeft} (value ${arr[nextLeft]}).`,
        ...prev
      ]);
    } else {
      const nextRight = right - 1;
      setRight(nextRight);
      setHistory(prev => [
        `Sum (${currentSum}) > ${target}. Decremented Right pointer to index ${nextRight} (value ${arr[nextRight]}).`,
        ...prev
      ]);
    }
  };

  return (
    <div className="visualizer-container">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <div>
          <span className="badge badge-accent" style={{ marginBottom: 4 }}>Interactive Simulation</span>
          <h4 style={{ fontSize: '1.1rem', fontWeight: 700 }}>Two-Pointer Convergence Simulator</h4>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
            Watch the sorted search space reduce in linear O(n) operations instead of quadratic O(n²).
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>Target Sum:</label>
          <select 
            value={target} 
            onChange={e => { setTarget(Number(e.target.value)); reset(); }}
            style={{ padding: '4px 8px' }}
          >
            <option value={14}>14 (Found at 7 + 7? No, 11+... wait: 4 + ...)</option>
            <option value={15}>15 (4 + 11)</option>
            <option value={18}>18 (7 + 11)</option>
            <option value={20}>20 (7 + 13 or 9 + 11)</option>
            <option value={24}>24 (4 + 20 or 11 + 13)</option>
            <option value={99}>99 (No solution)</option>
          </select>
          <button onClick={reset} className="btn-secondary" style={{ padding: '6px 12px', fontSize: '0.8rem' }}>
            <RotateCcw size={14} /> Reset
          </button>
        </div>
      </div>

      {/* Array Elements Visual Representation */}
      <div style={{ display: 'flex', gap: 8, justifyContent: 'center', margin: '30px 0', flexWrap: 'wrap' }}>
        {arr.map((val, idx) => {
          const isLeft = idx === left;
          const isRight = idx === right;
          const isSelected = isLeft || isRight;

          return (
            <div key={idx} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: 56 }}>
              {/* Pointer Indicator */}
              <div style={{ height: 26, fontSize: '0.75rem', fontWeight: 700 }}>
                {isLeft && <span style={{ color: '#38bdf8' }}>LEFT ↓</span>}
                {isRight && <span style={{ color: '#ec4899' }}>RIGHT ↓</span>}
              </div>

              {/* Element Card */}
              <div
                style={{
                  width: 54,
                  height: 54,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: 800,
                  fontSize: '1.2rem',
                  fontFamily: 'var(--font-mono)',
                  borderRadius: 10,
                  border: isSelected 
                    ? `2px solid ${isLeft ? '#38bdf8' : '#ec4899'}` 
                    : '1px solid var(--border-subtle)',
                  background: found && isSelected 
                    ? 'rgba(16, 185, 129, 0.3)' 
                    : isSelected 
                    ? 'rgba(99, 102, 241, 0.25)' 
                    : 'rgba(255, 255, 255, 0.03)',
                  color: isSelected ? '#ffffff' : 'var(--text-muted)',
                  boxShadow: isSelected ? '0 0 16px rgba(99, 102, 241, 0.3)' : 'none',
                  transition: 'all 0.3s ease'
                }}
              >
                {val}
              </div>

              {/* Index Subtext */}
              <span style={{ fontSize: '0.7rem', color: 'var(--text-dim)', marginTop: 6, fontFamily: 'var(--font-mono)' }}>
                idx[{idx}]
              </span>
            </div>
          );
        })}
      </div>

      {/* Real-time Calculation Panel */}
      <div 
        style={{
          background: 'rgba(255, 255, 255, 0.03)',
          borderRadius: 10,
          padding: '14px 20px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          border: '1px solid var(--border-subtle)'
        }}
      >
        <div style={{ display: 'flex', gap: 20, alignItems: 'center' }}>
          <div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)', textTransform: 'uppercase' }}>Formula Evaluation</span>
            <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: '1.05rem', marginTop: 2 }}>
              <span style={{ color: '#38bdf8' }}>arr[{left}] ({arr[left]})</span>
              {' + '}
              <span style={{ color: '#ec4899' }}>arr[{right}] ({arr[right]})</span>
              {' = '}
              <span style={{ color: currentSum === target ? '#10b981' : currentSum > target ? '#f43f5e' : '#fbbf24' }}>
                {currentSum}
              </span>
              <span style={{ color: 'var(--text-dim)', marginLeft: 8 }}>(Target: {target})</span>
            </div>
          </div>
        </div>

        <button 
          onClick={stepNext}
          disabled={found || left >= right}
          className="btn-primary"
          style={{ opacity: (found || left >= right) ? 0.5 : 1 }}
        >
          {found ? <CheckCircle size={18} /> : <Play size={18} />}
          {found ? "Target Identified!" : left >= right ? "Pointers Crossed" : "Step Algorithm"}
        </button>
      </div>

      {/* Execution Log */}
      <div style={{ marginTop: 14 }}>
        <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)', fontWeight: 600 }}>STEP LOG</span>
        <div 
          style={{
            maxHeight: 90,
            overflowY: 'auto',
            background: '#060a12',
            padding: '8px 12px',
            borderRadius: 8,
            fontFamily: 'var(--font-mono)',
            fontSize: '0.8rem',
            marginTop: 4,
            border: '1px solid rgba(255, 255, 255, 0.05)'
          }}
        >
          {history.map((log, i) => (
            <div key={i} style={{ color: i === 0 ? '#38bdf8' : 'var(--text-dim)', marginBottom: 2 }}>
              {`> `}{log}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
