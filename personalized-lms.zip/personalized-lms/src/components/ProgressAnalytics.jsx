import React, { useState } from 'react';
import { 
  Award, 
  BarChart2, 
  Clock, 
  Flame, 
  TrendingUp, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight,
  Filter
} from 'lucide-react';

export default function ProgressAnalytics({ student, onGoToLesson }) {
  if (!student) return null;

  const [filterType, setFilterType] = useState('all');

  const competencies = student.competencies || {};
  const entries = Object.entries(competencies);

  const formatConcept = (tag) => {
    return tag.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
  };

  const filteredEntries = entries.filter(([concept, score]) => {
    if (filterType === 'mastered') return score >= 80;
    if (filterType === 'developing') return score >= 60 && score < 80;
    if (filterType === 'remedial') return score < 60;
    return true;
  });

  return (
    <div style={{ maxWidth: 1300, margin: '0 auto', padding: '32px 24px', display: 'flex', flexDirection: 'column', gap: 28 }}>
      
      {/* Header */}
      <div>
        <h2 style={{ fontSize: '1.75rem', fontWeight: 800 }}>Student Competency & Progress Analytics</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem', marginTop: 4 }}>
          Granular skill mastery profiles generated through continuous Item Response Theory assessments.
        </p>
      </div>

      {/* Competency Mastery Grid */}
      <div className="glass-panel" style={{ padding: 28 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
          <div>
            <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>Algorithmic Competencies Breakdown</h3>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-dim)', marginTop: 2 }}>
              Dynamic mastery scores updated after every adaptive interaction.
            </p>
          </div>

          {/* Filter Pills */}
          <div style={{ display: 'flex', gap: 8 }}>
            {[
              { id: 'all', label: 'All (12)' },
              { id: 'mastered', label: 'Mastered (≥80%)' },
              { id: 'developing', label: 'Developing (60-79%)' },
              { id: 'remedial', label: 'Needs Remediation (<60%)' }
            ].map(f => (
              <button
                key={f.id}
                onClick={() => setFilterType(f.id)}
                style={{
                  padding: '6px 14px',
                  borderRadius: 20,
                  fontSize: '0.8rem',
                  fontWeight: 600,
                  background: filterType === f.id ? 'var(--accent-primary)' : 'rgba(255, 255, 255, 0.05)',
                  color: filterType === f.id ? '#ffffff' : 'var(--text-muted)',
                  border: filterType === f.id ? '1px solid var(--accent-primary)' : '1px solid var(--border-subtle)'
                }}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Competencies Progress Bars List */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: 16 }}>
          {filteredEntries.map(([concept, score]) => {
            const isMastered = score >= 80;
            const isRemedial = score < 60;

            return (
              <div
                key={concept}
                style={{
                  background: 'rgba(255, 255, 255, 0.03)',
                  border: isRemedial ? '1px solid rgba(244, 63, 94, 0.25)' : '1px solid var(--border-subtle)',
                  borderRadius: 12,
                  padding: 16
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                  <span style={{ fontWeight: 700, fontSize: '0.9rem', color: '#ffffff' }}>
                    {formatConcept(concept)}
                  </span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span 
                      style={{ 
                        fontWeight: 800, 
                        fontSize: '0.95rem',
                        color: isMastered ? '#34d399' : isRemedial ? '#fb7185' : '#fbbf24' 
                      }}
                    >
                      {score}%
                    </span>
                    <span 
                      className={`badge badge-${isMastered ? 'easy' : isRemedial ? 'hard' : 'medium'}`}
                      style={{ fontSize: '0.65rem', padding: '2px 6px' }}
                    >
                      {isMastered ? 'Mastered' : isRemedial ? 'Remedial' : 'Developing'}
                    </span>
                  </div>
                </div>

                <div className="progress-track" style={{ height: 6 }}>
                  <div 
                    className="progress-fill" 
                    style={{ 
                      width: `${score}%`, 
                      background: isMastered 
                        ? 'linear-gradient(90deg, #10b981, #06b6d4)' 
                        : isRemedial 
                        ? '#f43f5e' 
                        : 'linear-gradient(90deg, #f59e0b, #6366f1)' 
                    }} 
                  />
                </div>

                {isRemedial && (
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 }}>
                    <span style={{ fontSize: '0.75rem', color: '#fb7185' }}>
                      Recommended: Targeted revision
                    </span>
                    <button
                      onClick={() => onGoToLesson('cs-101', 'les-2-1')}
                      style={{ fontSize: '0.75rem', color: '#a5b4fc', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}
                    >
                      Launch Review <ArrowRight size={12} />
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Historical Quiz Assessment Attempts */}
      <div className="glass-panel" style={{ padding: 28 }}>
        <h3 style={{ fontSize: '1.25rem', fontWeight: 800, marginBottom: 16 }}>Assessment History & Trajectory Logs</h3>
        
        {student.quizHistory && student.quizHistory.length > 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {student.quizHistory.map((item, idx) => (
              <div 
                key={idx}
                style={{
                  background: 'rgba(255, 255, 255, 0.03)',
                  border: '1px solid var(--border-subtle)',
                  borderRadius: 12,
                  padding: '16px 20px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  flexWrap: 'wrap',
                  gap: 16
                }}
              >
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <span style={{ fontWeight: 800, fontSize: '1.1rem', color: '#ffffff' }}>
                      Score: {item.score}%
                    </span>
                    <span 
                      className="badge" 
                      style={{ 
                        background: item.masteryChange.startsWith('+') ? 'rgba(16, 185, 129, 0.2)' : 'rgba(244, 63, 94, 0.2)',
                        color: item.masteryChange.startsWith('+') ? '#34d399' : '#fb7185'
                      }}
                    >
                      {item.masteryChange} Mastery
                    </span>
                  </div>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-dim)', marginTop: 4 }}>
                    {new Date(item.timestamp).toLocaleDateString()} • {item.questionsAnswered} items evaluated
                  </div>
                </div>

                {/* Trajectory */}
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)', marginRight: 6 }}>Trajectory:</span>
                  {item.difficultyTrajectory.map((tier, tIdx) => (
                    <span key={tIdx} className={`badge badge-${tier}`} style={{ fontSize: '0.65rem', padding: '2px 6px' }}>
                      {tier.charAt(0).toUpperCase()}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>No assessments completed yet.</p>
        )}
      </div>

      {/* Milestone Badges & Achievements Wall */}
      <div className="glass-panel" style={{ padding: 28 }}>
        <h3 style={{ fontSize: '1.25rem', fontWeight: 800, marginBottom: 16 }}>Milestone Badges & Mastery Accolades</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 16 }}>
          {student.badges?.map(badge => (
            <div 
              key={badge.id}
              style={{
                background: 'rgba(99, 102, 241, 0.08)',
                border: '1px solid rgba(99, 102, 241, 0.25)',
                borderRadius: 12,
                padding: 16,
                display: 'flex',
                alignItems: 'center',
                gap: 14
              }}
            >
              <div style={{ fontSize: '2rem' }}>{badge.icon}</div>
              <div>
                <h4 style={{ fontWeight: 700, fontSize: '0.95rem', color: '#ffffff' }}>{badge.title}</h4>
                <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: 2 }}>{badge.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
