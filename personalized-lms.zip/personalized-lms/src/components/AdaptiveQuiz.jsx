import React, { useState, useEffect } from 'react';
import { 
  Zap, 
  HelpCircle, 
  CheckCircle2, 
  XCircle, 
  ArrowRight, 
  RotateCcw, 
  Clock, 
  Award, 
  TrendingUp, 
  AlertTriangle,
  Lightbulb,
  Sparkles,
  BarChart2
} from 'lucide-react';

export default function AdaptiveQuiz({ 
  student, 
  courses, 
  preselectedCourseId, 
  preselectedModuleId, 
  onQuizFinished, 
  onGoToLesson 
}) {
  const [selectedCourseId, setSelectedCourseId] = useState(preselectedCourseId || 'cs-101');
  const [selectedModuleId, setSelectedModuleId] = useState(preselectedModuleId || '');
  
  // Quiz state
  const [sessionActive, setSessionActive] = useState(false);
  const [loading, setLoading] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(null);
  const [currentDifficulty, setCurrentDifficulty] = useState('medium');
  const [sessionHistory, setSessionHistory] = useState([]);
  
  // Active question interaction
  const [selectedOption, setSelectedOption] = useState(null);
  const [showHint, setShowHint] = useState(false);
  const [questionTimer, setQuestionTimer] = useState(0);
  const [answerSubmitted, setAnswerSubmitted] = useState(false);
  const [evalResult, setEvalResult] = useState(null);

  // Completed session evaluation report
  const [finalReport, setFinalReport] = useState(null);

  // Timer per question
  useEffect(() => {
    let interval = null;
    if (sessionActive && !answerSubmitted) {
      interval = setInterval(() => {
        setQuestionTimer(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [sessionActive, answerSubmitted, currentQuestion?.id]);

  const startQuiz = async () => {
    setLoading(true);
    setFinalReport(null);
    try {
      const res = await fetch('/api/quiz/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId: student?.id,
          courseId: selectedCourseId,
          moduleId: selectedModuleId || undefined
        })
      });
      const data = await res.json();
      if (data.success) {
        setCurrentQuestion(data.initialQuestion);
        setCurrentDifficulty(data.currentDifficulty);
        setSessionHistory([]);
        setSessionActive(true);
        setSelectedOption(null);
        setShowHint(false);
        setQuestionTimer(0);
        setAnswerSubmitted(false);
        setEvalResult(null);
      }
    } catch (err) {
      console.error('Failed to start adaptive quiz:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleOptionSelect = (index) => {
    if (answerSubmitted) return;
    setSelectedOption(index);
  };

  const handleSubmitAnswer = async () => {
    if (selectedOption === null || answerSubmitted) return;

    setLoading(true);
    try {
      const res = await fetch('/api/quiz/answer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId: student?.id,
          currentQuestionId: currentQuestion.id,
          selectedOptionIndex: selectedOption,
          usedHint: showHint,
          timeSpentSeconds: questionTimer,
          sessionHistory,
          courseId: selectedCourseId
        })
      });
      const data = await res.json();
      if (data.success) {
        setEvalResult(data);
        setAnswerSubmitted(true);
        setSessionHistory(data.sessionHistory);
      }
    } catch (err) {
      console.error('Error submitting answer:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleNextQuestion = async () => {
    if (evalResult?.isCompleted || !evalResult?.nextQuestion) {
      // Finalize quiz session
      completeQuiz(evalResult?.sessionHistory || sessionHistory);
    } else {
      setCurrentQuestion(evalResult.nextQuestion);
      setCurrentDifficulty(evalResult.nextDifficulty);
      setSelectedOption(null);
      setShowHint(false);
      setQuestionTimer(0);
      setAnswerSubmitted(false);
      setEvalResult(null);
    }
  };

  const completeQuiz = async (history) => {
    setLoading(true);
    try {
      const res = await fetch('/api/quiz/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId: student?.id,
          courseId: selectedCourseId,
          sessionHistory: history
        })
      });
      const data = await res.json();
      if (data.success) {
        setFinalReport(data.evaluation);
        setSessionActive(false);
        if (onQuizFinished) onQuizFinished(data.student);
      }
    } catch (err) {
      console.error('Failed to complete quiz:', err);
    } finally {
      setLoading(false);
    }
  };

  const formatConcept = (tag) => {
    if (!tag) return "";
    return tag.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
  };

  return (
    <div style={{ maxWidth: 1100, margin: '0 auto', padding: '32px 24px' }}>
      
      {/* View Header */}
      <div style={{ marginBottom: 28, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span className="badge badge-accent">Adaptive Item Response Theory</span>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>Real-Time Dynamic Difficulty</span>
          </div>
          <h2 style={{ fontSize: '1.75rem', fontWeight: 800 }}>Adaptive Assessment Engine</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginTop: 2 }}>
            Difficulty calibrates continuously to probe your exact mastery boundaries and locate concept gaps.
          </p>
        </div>

        {/* Dynamic Difficulty Gauge Bar */}
        {sessionActive && (
          <div 
            style={{ 
              background: 'rgba(255, 255, 255, 0.04)', 
              padding: '10px 18px', 
              borderRadius: 14, 
              border: '1px solid var(--border-subtle)',
              display: 'flex',
              alignItems: 'center',
              gap: 14
            }}
          >
            <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>
              Adaptive Gauge:
            </span>
            <div style={{ display: 'flex', gap: 6 }}>
              {['easy', 'medium', 'hard'].map(level => {
                const isCurrent = currentDifficulty === level;
                return (
                  <span
                    key={level}
                    className={`badge badge-${level}`}
                    style={{
                      opacity: isCurrent ? 1 : 0.35,
                      transform: isCurrent ? 'scale(1.08)' : 'scale(1)',
                      boxShadow: isCurrent ? '0 0 12px rgba(99, 102, 241, 0.5)' : 'none',
                      transition: 'all 0.3s ease'
                    }}
                  >
                    {level.toUpperCase()}
                  </span>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* State 1: Configuration Screen before starting */}
      {!sessionActive && !finalReport && (
        <div className="glass-panel" style={{ padding: 36, textAlign: 'center', maxWidth: 650, margin: '0 auto' }}>
          <div 
            style={{ 
              width: 68, 
              height: 68, 
              borderRadius: 20, 
              background: 'linear-gradient(135deg, rgba(99, 102, 241, 0.2), rgba(6, 182, 212, 0.2))', 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center', 
              margin: '0 auto 20px',
              border: '1px solid rgba(99, 102, 241, 0.4)'
            }}
          >
            <Zap size={32} color="#818cf8" />
          </div>

          <h3 style={{ fontSize: '1.4rem', fontWeight: 800 }}>Begin Calibrated Session</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginTop: 8, lineHeight: 1.6 }}>
            The quiz will automatically start at your estimated competency level. Every correct answer advances you toward higher analytical tiers, while incorrect responses trigger foundational diagnostics.
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 16, margin: '28px 0', textAlign: 'left' }}>
            <div>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>
                Target Subject:
              </label>
              <select 
                value={selectedCourseId} 
                onChange={e => setSelectedCourseId(e.target.value)}
                style={{ width: '100%', marginTop: 6, padding: '10px 12px' }}
              >
                {courses.map(c => (
                  <option key={c.id} value={c.id}>{c.title}</option>
                ))}
              </select>
            </div>
          </div>

          <button 
            onClick={startQuiz} 
            disabled={loading}
            className="btn-primary" 
            style={{ padding: '12px 32px', fontSize: '1rem', width: '100%' }}
          >
            <Zap size={18} /> {loading ? "Calibrating Session..." : "Launch Adaptive Assessment"}
          </button>
        </div>
      )}

      {/* State 2: Active Adaptive Question */}
      {sessionActive && currentQuestion && (
        <div className="glass-panel" style={{ padding: 32 }}>
          {/* Question Subheader Info */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span className={`badge badge-${currentQuestion.difficulty}`}>
                {currentQuestion.difficulty} Tier
              </span>
              <span className="badge badge-accent">
                {formatConcept(currentQuestion.conceptTag)}
              </span>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 16, fontSize: '0.85rem', color: 'var(--text-muted)' }}>
              <span>Question {sessionHistory.length + 1} of 5</span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                <Clock size={14} color="#38bdf8" /> {questionTimer}s
              </span>
            </div>
          </div>

          {/* Question Prompt */}
          <h3 style={{ fontSize: '1.25rem', fontWeight: 700, color: '#ffffff', lineHeight: 1.5, marginBottom: 24 }}>
            {currentQuestion.question}
          </h3>

          {/* Options */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 24 }}>
            {currentQuestion.options.map((opt, idx) => {
              const isSelected = selectedOption === idx;
              let optionStyle = {
                padding: '14px 18px',
                borderRadius: 12,
                fontSize: '0.92rem',
                textAlign: 'left',
                border: '1px solid var(--border-subtle)',
                background: 'rgba(255, 255, 255, 0.03)',
                color: 'var(--text-main)',
                display: 'flex',
                alignItems: 'center',
                gap: 12,
                cursor: answerSubmitted ? 'default' : 'pointer'
              };

              if (isSelected && !answerSubmitted) {
                optionStyle.border = '2px solid #6366f1';
                optionStyle.background = 'rgba(99, 102, 241, 0.2)';
              }

              if (answerSubmitted) {
                if (idx === evalResult?.correctIndex) {
                  optionStyle.border = '2px solid #10b981';
                  optionStyle.background = 'rgba(16, 185, 129, 0.25)';
                  optionStyle.color = '#34d399';
                } else if (isSelected && !evalResult?.isCorrect) {
                  optionStyle.border = '2px solid #f43f5e';
                  optionStyle.background = 'rgba(244, 63, 94, 0.25)';
                  optionStyle.color = '#fb7185';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleOptionSelect(idx)}
                  style={optionStyle}
                  disabled={answerSubmitted}
                >
                  <span 
                    style={{ 
                      width: 28, 
                      height: 28, 
                      borderRadius: 8, 
                      background: isSelected ? 'var(--accent-primary)' : 'rgba(255, 255, 255, 0.08)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontWeight: 700,
                      fontSize: '0.8rem',
                      color: '#ffffff'
                    }}
                  >
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <span style={{ flex: 1 }}>{opt}</span>
                  {answerSubmitted && idx === evalResult?.correctIndex && (
                    <CheckCircle2 size={18} color="#10b981" />
                  )}
                  {answerSubmitted && isSelected && !evalResult?.isCorrect && (
                    <XCircle size={18} color="#f43f5e" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Conceptual Hint Section */}
          {!answerSubmitted && (
            <div style={{ marginBottom: 20 }}>
              {!showHint ? (
                <button
                  onClick={() => setShowHint(true)}
                  style={{
                    fontSize: '0.8rem',
                    color: '#93c5fd',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    padding: '6px 12px',
                    borderRadius: 8,
                    background: 'rgba(56, 189, 248, 0.08)'
                  }}
                >
                  <Lightbulb size={14} /> Request Conceptual Hint (Applies 20% point calibration penalty)
                </button>
              ) : (
                <div 
                  style={{
                    padding: '12px 16px',
                    borderRadius: 10,
                    background: 'rgba(56, 189, 248, 0.12)',
                    border: '1px solid rgba(56, 189, 248, 0.25)',
                    fontSize: '0.85rem',
                    color: '#e0f2fe'
                  }}
                >
                  <strong>💡 Conceptual Hint:</strong> {currentQuestion.hint}
                </div>
              )}
            </div>
          )}

          {/* Dynamic Adaptation Banner & Pedagogical Explanation */}
          {answerSubmitted && evalResult && (
            <div 
              style={{
                marginTop: 20,
                padding: '18px 22px',
                borderRadius: 12,
                background: evalResult.isCorrect ? 'rgba(16, 185, 129, 0.12)' : 'rgba(244, 63, 94, 0.12)',
                border: evalResult.isCorrect ? '1px solid rgba(16, 185, 129, 0.3)' : '1px solid rgba(244, 63, 94, 0.3)',
                display: 'flex',
                flexDirection: 'column',
                gap: 8
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                {evalResult.isCorrect ? (
                  <CheckCircle2 size={20} color="#10b981" />
                ) : (
                  <XCircle size={20} color="#f43f5e" />
                )}
                <strong style={{ color: evalResult.isCorrect ? '#34d399' : '#fb7185', fontSize: '1rem' }}>
                  {evalResult.isCorrect ? "Correct Response!" : "Incorrect Response"}
                </strong>
              </div>

              <p style={{ fontSize: '0.88rem', color: '#e2e8f0' }}>
                {evalResult.explanation}
              </p>

              {/* Dynamic Difficulty Transition Notification */}
              <div 
                style={{ 
                  marginTop: 6, 
                  padding: '8px 12px', 
                  borderRadius: 8, 
                  background: 'rgba(0, 0, 0, 0.3)', 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: 8,
                  fontSize: '0.8rem',
                  color: '#818cf8',
                  fontWeight: 600
                }}
              >
                <TrendingUp size={16} />
                <span>Adaptive Transition: {evalResult.adaptationReason}</span>
              </div>
            </div>
          )}

          {/* Action Footer */}
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 24, gap: 12 }}>
            {!answerSubmitted ? (
              <button
                onClick={handleSubmitAnswer}
                disabled={selectedOption === null || loading}
                className="btn-primary"
                style={{ opacity: selectedOption === null ? 0.5 : 1, padding: '12px 28px' }}
              >
                {loading ? "Evaluating..." : "Submit Answer"}
              </button>
            ) : (
              <button
                onClick={handleNextQuestion}
                className="btn-primary"
                style={{ padding: '12px 28px' }}
              >
                {evalResult?.isCompleted ? "View Diagnostic Report" : "Proceed to Next Calibrated Item"} <ArrowRight size={16} />
              </button>
            )}
          </div>
        </div>
      )}

      {/* State 3: Diagnostic Report Screen (Post-Quiz Analysis) */}
      {finalReport && (
        <div className="glass-panel" style={{ padding: 36 }}>
          <div style={{ textAlign: 'center', marginBottom: 28 }}>
            <div 
              style={{
                width: 72,
                height: 72,
                borderRadius: '50%',
                background: finalReport.percentageScore >= 70 ? 'rgba(16, 185, 129, 0.2)' : 'rgba(245, 158, 11, 0.2)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 16px',
                border: `2px solid ${finalReport.percentageScore >= 70 ? '#10b981' : '#f59e0b'}`
              }}
            >
              <Award size={36} color={finalReport.percentageScore >= 70 ? '#10b981' : '#f59e0b'} />
            </div>

            <h2 style={{ fontSize: '1.75rem', fontWeight: 800 }}>Adaptive Assessment Diagnostics</h2>
            <div style={{ fontSize: '2.5rem', fontWeight: 800, color: '#ffffff', marginTop: 8 }}>
              {finalReport.percentageScore}%
            </div>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem', maxWidth: 600, margin: '8px auto 0' }}>
              {finalReport.feedbackSummary}
            </p>
          </div>

          {/* Difficulty Trajectory Visualization */}
          <div style={{ background: 'rgba(255, 255, 255, 0.03)', padding: 20, borderRadius: 12, marginBottom: 24, border: '1px solid var(--border-subtle)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>
                Item Response Trajectory (Difficulty Level Progression)
              </span>
              <span style={{ fontSize: '0.8rem', color: '#818cf8', fontWeight: 600 }}>
                {finalReport.difficultyTrajectory.length} Steps
              </span>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 12, overflowX: 'auto', padding: '10px 0' }}>
              {finalReport.difficultyTrajectory.map((tier, idx) => (
                <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div 
                    style={{ 
                      display: 'flex', 
                      flexDirection: 'column', 
                      alignItems: 'center', 
                      background: 'rgba(0, 0, 0, 0.4)', 
                      padding: '10px 16px', 
                      borderRadius: 10,
                      border: '1px solid var(--border-subtle)'
                    }}
                  >
                    <span style={{ fontSize: '0.7rem', color: 'var(--text-dim)', marginBottom: 4 }}>
                      Step #{idx + 1}
                    </span>
                    <span className={`badge badge-${tier}`}>
                      {tier.toUpperCase()}
                    </span>
                  </div>
                  {idx < finalReport.difficultyTrajectory.length - 1 && (
                    <ArrowRight size={16} color="var(--text-dim)" />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Mastered vs Remedial Breakdown */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 28 }}>
            
            {/* Mastered concepts */}
            <div style={{ background: 'rgba(16, 185, 129, 0.06)', border: '1px solid rgba(16, 185, 129, 0.25)', borderRadius: 12, padding: 20 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                <CheckCircle2 size={18} color="#10b981" />
                <h4 style={{ fontSize: '0.95rem', fontWeight: 700, color: '#34d399' }}>Mastered Competencies</h4>
              </div>
              {finalReport.masteredConcepts?.length > 0 ? (
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                  {finalReport.masteredConcepts.map(c => (
                    <span key={c} className="badge badge-easy">{formatConcept(c)}</span>
                  ))}
                </div>
              ) : (
                <p style={{ fontSize: '0.82rem', color: 'var(--text-dim)' }}>Continue practicing to solidify high-tier mastery.</p>
              )}
            </div>

            {/* Weak / Remedial concepts */}
            <div style={{ background: 'rgba(244, 63, 94, 0.06)', border: '1px solid rgba(244, 63, 94, 0.25)', borderRadius: 12, padding: 20 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                <AlertTriangle size={18} color="#fb7185" />
                <h4 style={{ fontSize: '0.95rem', fontWeight: 700, color: '#fb7185' }}>Target Remediation Focus</h4>
              </div>
              {finalReport.weakConcepts?.length > 0 ? (
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                  {finalReport.weakConcepts.map(c => (
                    <span key={c} className="badge badge-hard">{formatConcept(c)}</span>
                  ))}
                </div>
              ) : (
                <p style={{ fontSize: '0.82rem', color: 'var(--text-dim)' }}>Zero critical gaps detected in this assessment batch!</p>
              )}
            </div>
          </div>

          {/* Action buttons */}
          <div style={{ display: 'flex', justifyContent: 'center', gap: 14 }}>
            <button 
              onClick={() => { setFinalReport(null); setSessionActive(false); }}
              className="btn-secondary"
            >
              <RotateCcw size={16} /> Retake Assessment
            </button>
            {finalReport.weakConcepts?.length > 0 && (
              <button 
                onClick={() => onGoToLesson('cs-101', 'les-2-1')}
                className="btn-primary"
              >
                Launch Remedial Micro-Lesson <ArrowRight size={16} />
              </button>
            )}
          </div>
        </div>
      )}

    </div>
  );
}
