import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  CheckCircle2, 
  Circle, 
  Clock, 
  Play, 
  BookOpen, 
  Zap, 
  Code, 
  Eye, 
  Timer, 
  ChevronRight,
  Sparkles
} from 'lucide-react';
import TwoPointerVisualizer from './visualizers/TwoPointerVisualizer.jsx';
import CallStackSimulator from './visualizers/CallStackSimulator.jsx';
import TreeVisualizer from './visualizers/TreeVisualizer.jsx';

export default function CourseViewer({ 
  course, 
  student, 
  initialLessonId, 
  onBack, 
  onStartQuiz, 
  onCompleteLesson 
}) {
  if (!course) return null;

  // Flatten lessons
  const allLessons = course.modules.flatMap(m => m.lessons.map(l => ({ ...l, moduleId: m.id, moduleTitle: m.title })));
  const defaultLesson = allLessons.find(l => l.id === initialLessonId) || allLessons[0];
  
  const [activeLesson, setActiveLesson] = useState(defaultLesson);
  const [activeTab, setActiveTab] = useState(defaultLesson?.interactive ? 'interactive' : 'reading');
  const [timeSpentSeconds, setTimeSpentSeconds] = useState(0);
  const [isCompletedInSession, setIsCompletedInSession] = useState(false);

  const enrollment = student?.enrolledCourses?.find(e => e.courseId === course.id);
  const completedLessonIds = enrollment?.completedLessonIds || [];

  // Active time-on-task timer for engagement calculation
  useEffect(() => {
    setTimeSpentSeconds(0);
    setIsCompletedInSession(false);
    const interval = setInterval(() => {
      setTimeSpentSeconds(prev => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [activeLesson?.id]);

  const handleSelectLesson = (lesson) => {
    setActiveLesson(lesson);
    setActiveTab(lesson.interactive ? 'interactive' : 'reading');
  };

  const handleMarkComplete = () => {
    setIsCompletedInSession(true);
    onCompleteLesson(course.id, activeLesson.id, Math.max(1, Math.round(timeSpentSeconds / 60)));
  };

  const isCompleted = completedLessonIds.includes(activeLesson?.id) || isCompletedInSession;

  const renderVisualizer = (type) => {
    switch (type) {
      case 'two-pointer-visualizer':
        return <TwoPointerVisualizer />;
      case 'call-stack-simulator':
        return <CallStackSimulator />;
      case 'tree-visualizer':
        return <TreeVisualizer />;
      default:
        return (
          <div className="visualizer-container" style={{ textAlign: 'center', padding: 40 }}>
            <Sparkles size={32} color="#818cf8" style={{ margin: '0 auto 12px' }} />
            <h4 style={{ fontWeight: 700 }}>Interactive Code Sandbox</h4>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginTop: 6 }}>
              Interactive sandbox environment calibrated for this lesson.
            </p>
          </div>
        );
    }
  };

  return (
    <div style={{ maxWidth: 1400, margin: '0 auto', padding: '24px' }}>
      {/* Top Breadcrumb & Action bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <button 
          onClick={onBack} 
          className="btn-secondary" 
          style={{ padding: '8px 14px', fontSize: '0.85rem' }}
        >
          <ArrowLeft size={16} /> Back to Courses
        </button>

        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div 
            style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: 6, 
              background: 'rgba(255, 255, 255, 0.05)', 
              padding: '6px 12px', 
              borderRadius: 20,
              fontSize: '0.8rem',
              color: 'var(--text-muted)'
            }}
          >
            <Timer size={14} color="#38bdf8" />
            <span>Time on lesson: <strong style={{ color: '#ffffff' }}>{Math.floor(timeSpentSeconds / 60)}m {timeSpentSeconds % 60}s</strong></span>
          </div>

          <button 
            onClick={() => onStartQuiz(course.id, activeLesson?.moduleId)} 
            className="btn-primary"
            style={{ padding: '8px 16px', fontSize: '0.85rem' }}
          >
            <Zap size={16} /> Take Adaptive Quiz
          </button>
        </div>
      </div>

      {/* Main Grid: Sidebar Syllabus + Lesson Content Viewer */}
      <div style={{ display: 'grid', gridTemplateColumns: '320px 1fr', gap: 24, alignItems: 'start' }}>
        
        {/* Sidebar: Syllabus Outline */}
        <div className="glass-panel" style={{ padding: 18, maxHeight: 'calc(100vh - 160px)', overflowY: 'auto' }}>
          <h4 style={{ fontSize: '1rem', fontWeight: 800, marginBottom: 12 }}>{course.title}</h4>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 700 }}>
            Curriculum Modules
          </span>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 16, marginTop: 12 }}>
            {course.modules.map((mod) => (
              <div key={mod.id}>
                <div style={{ fontSize: '0.82rem', fontWeight: 700, color: '#a5b4fc', marginBottom: 6 }}>
                  {mod.title}
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                  {mod.lessons.map(lesson => {
                    const isSelected = activeLesson?.id === lesson.id;
                    const isDone = completedLessonIds.includes(lesson.id);

                    return (
                      <button
                        key={lesson.id}
                        onClick={() => handleSelectLesson({ ...lesson, moduleId: mod.id, moduleTitle: mod.title })}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: 10,
                          padding: '8px 10px',
                          borderRadius: 8,
                          textAlign: 'left',
                          fontSize: '0.8rem',
                          background: isSelected ? 'rgba(99, 102, 241, 0.2)' : 'transparent',
                          border: isSelected ? '1px solid rgba(99, 102, 241, 0.4)' : '1px solid transparent',
                          color: isSelected ? '#ffffff' : 'var(--text-muted)'
                        }}
                      >
                        {isDone ? (
                          <CheckCircle2 size={16} color="#10b981" />
                        ) : (
                          <Circle size={16} color="var(--text-dim)" />
                        )}
                        <span style={{ flex: 1, fontWeight: isSelected ? 700 : 500 }}>
                          {lesson.title}
                        </span>
                        {lesson.interactive && (
                          <span style={{ fontSize: '0.7rem', color: '#38bdf8' }}>Interactive</span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Lesson Viewer & Interactive Sandbox */}
        <div className="glass-panel" style={{ padding: 28 }}>
          {/* Lesson Header */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '1px solid var(--border-subtle)', paddingBottom: 16, marginBottom: 20 }}>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                <span className="badge badge-accent">{activeLesson.moduleTitle}</span>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>
                  <Clock size={12} style={{ display: 'inline', marginRight: 4 }} />
                  {activeLesson.duration}
                </span>
              </div>
              <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>{activeLesson.title}</h2>
            </div>

            {/* Completion Button */}
            <button
              onClick={handleMarkComplete}
              disabled={isCompleted}
              className={isCompleted ? "btn-secondary" : "btn-primary"}
              style={{
                background: isCompleted ? 'rgba(16, 185, 129, 0.15)' : undefined,
                color: isCompleted ? '#34d399' : undefined,
                border: isCompleted ? '1px solid rgba(16, 185, 129, 0.3)' : undefined
              }}
            >
              <CheckCircle2 size={16} />
              {isCompleted ? "Lesson Completed" : "Mark Complete & Boost Engagement"}
            </button>
          </div>

          {/* View Mode Tabs (Reading vs Simulation) */}
          {activeLesson.interactive && (
            <div style={{ display: 'flex', gap: 10, marginBottom: 20 }}>
              <button
                onClick={() => setActiveTab('interactive')}
                style={{
                  padding: '8px 16px',
                  borderRadius: 8,
                  fontSize: '0.85rem',
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  background: activeTab === 'interactive' ? 'var(--accent-primary)' : 'rgba(255, 255, 255, 0.05)',
                  color: activeTab === 'interactive' ? '#ffffff' : 'var(--text-muted)'
                }}
              >
                <Eye size={16} /> Interactive Visualizer
              </button>
              <button
                onClick={() => setActiveTab('reading')}
                style={{
                  padding: '8px 16px',
                  borderRadius: 8,
                  fontSize: '0.85rem',
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  background: activeTab === 'reading' ? 'var(--accent-primary)' : 'rgba(255, 255, 255, 0.05)',
                  color: activeTab === 'reading' ? '#ffffff' : 'var(--text-muted)'
                }}
              >
                <BookOpen size={16} /> Theoretical Foundations
              </button>
            </div>
          )}

          {/* Active Content Body */}
          {activeTab === 'interactive' && activeLesson.interactive ? (
            renderVisualizer(activeLesson.interactiveType)
          ) : (
            <div 
              style={{ 
                fontSize: '0.95rem', 
                color: '#e2e8f0', 
                lineHeight: 1.7,
                whiteSpace: 'pre-line' 
              }}
            >
              {activeLesson.content}
            </div>
          )}

          {/* Post-Lesson Prompt for Adaptive Quiz */}
          <div 
            style={{ 
              marginTop: 32, 
              padding: 20, 
              background: 'rgba(99, 102, 241, 0.08)', 
              borderRadius: 12, 
              border: '1px solid rgba(99, 102, 241, 0.2)',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center'
            }}
          >
            <div>
              <h4 style={{ fontWeight: 700, fontSize: '1rem', color: '#ffffff' }}>Ready to calibrate your mastery?</h4>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: 4 }}>
                The adaptive engine will dynamically select questions based on your performance in this module.
              </p>
            </div>
            <button 
              onClick={() => onStartQuiz(course.id, activeLesson.moduleId)} 
              className="btn-primary"
            >
              <Zap size={16} /> Start Adaptive Diagnostic
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
