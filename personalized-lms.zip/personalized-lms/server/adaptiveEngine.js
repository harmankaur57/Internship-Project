/**
 * Adaptive Quiz Engine & Recommendation Engine
 * Implements Item Response Theory (IRT) dynamic difficulty adjustment
 * and multi-factor pedagogical recommendation generation.
 */

// Difficulty weights and transitions
const DIFFICULTY_LEVELS = ['easy', 'medium', 'hard'];

export function selectInitialQuestion(questions, student, courseId, moduleId) {
  // Filter questions for the specific course/module if provided, or course in general
  let pool = questions.filter(q => q.courseId === courseId);
  if (moduleId) {
    const modulePool = pool.filter(q => q.moduleId === moduleId);
    if (modulePool.length > 0) pool = modulePool;
  }

  // Calibrate starting difficulty based on student average competency in these concepts
  let avgCompetency = 65; // default moderate
  if (student && student.competencies) {
    const relevantScores = pool
      .map(q => student.competencies[q.conceptTag])
      .filter(score => typeof score === 'number');
    if (relevantScores.length > 0) {
      avgCompetency = relevantScores.reduce((a, b) => a + b, 0) / relevantScores.length;
    }
  }

  let startingDifficulty = 'medium';
  if (avgCompetency < 55) {
    startingDifficulty = 'easy';
  } else if (avgCompetency >= 80) {
    startingDifficulty = 'hard';
  }

  // Find a question of starting difficulty, fallback to medium or any available
  let initial = pool.find(q => q.difficulty === startingDifficulty) ||
                pool.find(q => q.difficulty === 'medium') ||
                pool[0];

  return {
    question: initial,
    currentDifficulty: startingDifficulty,
    totalAvailable: pool.length
  };
}

export function processAnswerAndPickNext({
  currentQuestion,
  selectedOptionIndex,
  usedHint,
  timeSpentSeconds,
  sessionHistory, // array of past attempts in this session
  questionsPool,
  student
}) {
  const isCorrect = selectedOptionIndex === currentQuestion.correctIndex;
  const currentDiff = currentQuestion.difficulty;

  // Determine next difficulty tier based on performance
  let nextDifficulty = currentDiff;
  let reason = '';

  if (isCorrect) {
    if (currentDiff === 'easy') {
      nextDifficulty = 'medium';
      reason = 'Great job on the fundamentals! Stepping up to Medium difficulty.';
    } else if (currentDiff === 'medium') {
      nextDifficulty = 'hard';
      reason = 'Excellent grasp of core logic! Escalating to Hard challenge tier.';
    } else {
      nextDifficulty = 'hard';
      reason = 'Flawless mastery at Hard tier! Continuing high-order problem solving.';
    }
  } else {
    if (currentDiff === 'hard') {
      nextDifficulty = 'medium';
      reason = 'Challenging question! Calibrating to Medium tier to reinforce core mechanics.';
    } else if (currentDiff === 'medium') {
      nextDifficulty = 'easy';
      reason = 'Concept stumbled! Adapting to Easy tier to solidify foundational invariants.';
    } else {
      nextDifficulty = 'easy';
      reason = 'Reviewing foundational definitions. Remedial hints unlocked.';
    }
  }

  // Record this step into session history
  const updatedHistory = [
    ...sessionHistory,
    {
      questionId: currentQuestion.id,
      conceptTag: currentQuestion.conceptTag,
      difficulty: currentDiff,
      isCorrect,
      usedHint: Boolean(usedHint),
      timeSpentSeconds: timeSpentSeconds || 15
    }
  ];

  // Pick next question: must not have been asked in this session
  const askedIds = new Set(updatedHistory.map(h => h.questionId));
  const availableQuestions = questionsPool.filter(q => !askedIds.has(q.id));

  // Try matching preferred nextDifficulty
  let nextQ = availableQuestions.find(q => q.difficulty === nextDifficulty);

  // If no question of exact nextDifficulty is available, fallback to adjacent tier
  if (!nextQ) {
    nextQ = availableQuestions.find(q => q.difficulty === 'medium') ||
            availableQuestions.find(q => q.difficulty === 'easy') ||
            availableQuestions[0];
  }

  const isCompleted = updatedHistory.length >= 5 || !nextQ;

  return {
    isCorrect,
    correctIndex: currentQuestion.correctIndex,
    explanation: currentQuestion.explanation,
    adaptationReason: reason,
    nextDifficulty,
    nextQuestion: isCompleted ? null : nextQ,
    isCompleted,
    sessionHistory: updatedHistory
  };
}

export function finalizeAdaptiveSession({ sessionHistory, questionsPool, student, courseId }) {
  let totalScore = 0;
  let maxPossible = 0;
  const conceptOutcomes = {};
  const difficultyTrajectory = [];

  sessionHistory.forEach(record => {
    difficultyTrajectory.push(record.difficulty);

    const weight = record.difficulty === 'hard' ? 30 : record.difficulty === 'medium' ? 20 : 10;
    maxPossible += weight;

    let pointsEarned = 0;
    if (record.isCorrect) {
      pointsEarned = weight;
      if (record.usedHint) pointsEarned = Math.round(weight * 0.8); // 20% deduction for using hint
    }
    totalScore += pointsEarned;

    // Track concept stats
    if (!conceptOutcomes[record.conceptTag]) {
      conceptOutcomes[record.conceptTag] = { correct: 0, total: 0, difficulties: [] };
    }
    conceptOutcomes[record.conceptTag].total += 1;
    conceptOutcomes[record.conceptTag].difficulties.push(record.difficulty);
    if (record.isCorrect) {
      conceptOutcomes[record.conceptTag].correct += 1;
    }
  });

  const percentageScore = maxPossible > 0 ? Math.round((totalScore / maxPossible) * 100) : 0;

  // Identify strengths and remediation needs
  const masteredConcepts = [];
  const weakConcepts = [];

  Object.entries(conceptOutcomes).forEach(([concept, stats]) => {
    const accuracy = stats.correct / stats.total;
    if (accuracy >= 0.75) {
      masteredConcepts.push(concept);
    } else {
      weakConcepts.push(concept);
    }
  });

  // Calculate student competency updates
  const updatedCompetencies = { ...(student.competencies || {}) };
  Object.entries(conceptOutcomes).forEach(([concept, stats]) => {
    const currentComp = updatedCompetencies[concept] || 50;
    const delta = (stats.correct / stats.total >= 0.5) ? (stats.correct * 6) : -(stats.total - stats.correct) * 6;
    updatedCompetencies[concept] = Math.max(10, Math.min(100, Math.round(currentComp + delta)));
  });

  // Recalculate overall mastery
  const compValues = Object.values(updatedCompetencies);
  const newOverallMastery = compValues.length > 0 
    ? Math.round(compValues.reduce((a, b) => a + b, 0) / compValues.length)
    : student.overallMastery;

  return {
    totalScore,
    maxPossible,
    percentageScore,
    masteredConcepts,
    weakConcepts,
    difficultyTrajectory,
    updatedCompetencies,
    newOverallMastery,
    feedbackSummary: percentageScore >= 80 
      ? "Exceptional Mastery! You demonstrated agility across high-difficulty analytical tiers."
      : percentageScore >= 60
      ? "Solid Foundation! You successfully navigated intermediate tiers with targeted areas for refinement."
      : "Adaptive Diagnostic Complete. Remedial study paths have been generated to solidify fundamentals."
  };
}

/**
 * Multi-Factor Personalized Recommendation Engine
 * Factors:
 * 1. Performance / Weak Concept Remediation
 * 2. High-Mastery Enrichment / Accelerated Track
 * 3. Engagement Score & Study Cadence
 * 4. Preferred Learning Modality (Visual / Practical / Theoretical)
 */
export function generateRecommendations(student, courses, allQuestions) {
  const recommendations = [];

  if (!student) return recommendations;

  const competencies = student.competencies || {};
  const engagement = student.engagementScore || 50;
  const learningStyle = student.preferredLearningStyle || 'visual';

  // --- FACTOR 1: Weak Concept Remedial Bites ---
  const weakTags = Object.entries(competencies)
    .filter(([_, score]) => score < 65)
    .sort((a, b) => a[1] - b[1]); // lowest first

  if (weakTags.length > 0) {
    const [lowestConcept, score] = weakTags[0];
    
    // Find relevant lesson or module
    let matchedCourse = courses.find(c => 
      c.modules.some(m => m.concepts && m.concepts.includes(lowestConcept))
    );
    let matchedLesson = null;
    let matchedModule = null;

    if (matchedCourse) {
      matchedModule = matchedCourse.modules.find(m => m.concepts && m.concepts.includes(lowestConcept));
      if (matchedModule && matchedModule.lessons.length > 0) {
        matchedLesson = matchedModule.lessons[0];
      }
    }

    recommendations.push({
      id: `rec-remedial-${lowestConcept}`,
      type: "remediation",
      badge: "Targeted Remediation",
      priority: "high",
      title: `Reinforce: ${formatConceptTitle(lowestConcept)}`,
      description: `Your mastery on this concept is currently at ${score}%. A quick focused review will strengthen your foundation before advancing.`,
      courseId: matchedCourse ? matchedCourse.id : "cs-101",
      moduleId: matchedModule ? matchedModule.id : "mod-2",
      lessonId: matchedLesson ? matchedLesson.id : "les-2-1",
      actionText: "Launch Remedial Lesson",
      estimatedMinutes: 15,
      reason: `Triggered by diagnostic score (${score}% on ${lowestConcept})`,
      modalityMatch: learningStyle === 'visual' ? "Interactive Visualization Included" : "Guided Breakdown"
    });
  }

  // --- FACTOR 2: High Mastery Accelerated Track ---
  const strongTags = Object.entries(competencies)
    .filter(([_, score]) => score >= 85);

  if (strongTags.length >= 2) {
    recommendations.push({
      id: "rec-acceleration-challenge",
      type: "accelerated",
      badge: "Honors Fast-Track",
      priority: "medium",
      title: "Hard-Tier Algorithmic Challenge",
      description: "You've proven >85% mastery on core linear and tree structures! Test your skills against complex edge-case optimizations.",
      courseId: "cs-101",
      moduleId: "mod-4",
      actionText: "Take Advanced Quiz Challenge",
      estimatedMinutes: 20,
      reason: `Triggered by high mastery in ${strongTags.map(t => formatConceptTitle(t[0])).slice(0, 2).join(' & ')}`,
      modalityMatch: "Multi-tiered dynamic difficulty"
    });
  }

  // --- FACTOR 3: Engagement Calibrator ---
  if (engagement < 50) {
    // Student is at risk or low engagement -> provide low-friction bite-sized win
    recommendations.push({
      id: "rec-engagement-micro",
      type: "engagement",
      badge: "Quick Win (5 Min)",
      priority: "urgent",
      title: "Interactive Two-Pointer Playground",
      description: "Short on time today? Complete this quick 5-minute interactive drag-and-inspect visualizer to keep your learning momentum active.",
      courseId: "cs-101",
      moduleId: "mod-1",
      lessonId: "les-1-2",
      actionText: "Start 5-Min Simulation",
      estimatedMinutes: 5,
      reason: "Calibrated to rebuild learning momentum with low-friction micro-learning",
      modalityMatch: "Visual simulation without heavy reading"
    });
  } else if (student.streakDays >= 5) {
    // Maintain streak reward
    recommendations.push({
      id: "rec-streak-continuation",
      type: "streak",
      badge: `${student.streakDays}-Day Streak Active`,
      priority: "medium",
      title: "Module 3: BST Traversal Invariants",
      description: `Keep your ${student.streakDays}-day streak glowing! Advance 1 lesson in Binary Search Trees to reach this week's milestone.`,
      courseId: "cs-101",
      moduleId: "mod-3",
      lessonId: "les-3-1",
      actionText: "Continue Course",
      estimatedMinutes: 25,
      reason: `Sustaining your ${student.streakDays}-day study streak`,
      modalityMatch: "Structured progression"
    });
  }

  // --- FACTOR 4: Cross-Disciplinary Elective Recommendation ---
  const hasEnrolledML = student.enrolledCourses.some(e => e.courseId === "ml-301");
  if (!hasEnrolledML && student.overallMastery >= 70) {
    recommendations.push({
      id: "rec-elective-ml",
      type: "discovery",
      badge: "Recommended Elective",
      priority: "low",
      title: "Explore: Machine Learning Foundations",
      description: "Based on your strong algorithmic foundations, you are primed to understand gradient optimization and neural networks.",
      courseId: "ml-301",
      actionText: "Explore Course Syllabus",
      estimatedMinutes: 30,
      reason: "Algorithmic competencies meet prerequisite benchmarks for Neural Networks",
      modalityMatch: "Interactive gradient visualizers"
    });
  }

  return recommendations;
}

function formatConceptTitle(tag) {
  if (!tag) return "";
  return tag
    .split('-')
    .map(w => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');
}
