import React from 'react';
import { X, Award, Activity, Flame, Clock, Zap, CheckCircle2, AlertTriangle } from 'lucide-react';

export default function StudentModal({ student, onClose, onIntervene }) {
  if (!student) return null;

  const competencies = student.competencies || {};

  const formatConcept = (tag) => {
    return tag.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
  };

  return (
    <div 
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(0, 0, 0, 0.75)',
        backdropFilter: 'blur(8px)',
        zIndex: 1000,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 20
      }}
    >
      <div 
        className="glass-panel" 
        style={{ 
          maxWidth: 700, 
          width: '100%', 
          maxHeight: '90vh', 
          overflowY: 'auto',
          padding: 28,
          position: 'relative'
        }}
      >
        {/* Close Button */}
        <button 
          onClick={onClose}
          style={{ 
            position: 'absolute', 
            top: 20, 
            right: 20, 
            color: 'var(--text-muted)',
            padding: 4
          }}
        >
          <X size={20} />
        </button>

        {/* Student Profile Header */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, borderBottom: '1px solid var(--border-subtle)', paddingBottom: 20, marginBottom: 20 }}>
          <img 
            src={student.avatar} 
            alt={student.name} 
            style={{ width: 64, height: 64, borderRadius: '50%', border: '2px solid var(--accent-primary)', objectFit: 'cover' }} 
          />
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <h3 style={{ fontSize: '1.3rem', fontWeight: 800 }}>{student.name}</h3>
              <span className={`badge badge-${student.engagementScore < 50 ? 'hard' : 'easy'}`}>
                {student.engagementScore < 50 ? 'At-Risk' : 'Active Learner'}
              </span>
            </div>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: 2 }}>
              {student.email} • Preferred Style: <strong style={{ color: '#ffffff', textTransform: 'capitalize' }}>{student.preferredLearningStyle}</strong>
            </p>
          </div>
        </div>

        {/* Key Metrics Row */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 24 }}>
          <div style={{ background: 'rgba(255, 255, 255, 0.03)', padding: 12, borderRadius: 10, textAlign: 'center' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)', textTransform: 'uppercase' }}>Overall Mastery</span>
            <div style={{ fontSize: '1.4rem', fontWeight: 800, color: '#ffffff', marginTop: 2 }}>{student.overallMastery}%</div>
          </div>
          <div style={{ background: 'rgba(255, 255, 255, 0.03)', padding: 12, borderRadius: 10, textAlign: 'center' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)', textTransform: 'uppercase' }}>Engagement</span>
            <div style={{ fontSize: '1.4rem', fontWeight: 800, color: student.engagementScore < 50 ? '#fb7185' : '#38bdf8', marginTop: 2 }}>
              {student.engagementScore}/100
            </div>
          </div>
          <div style={{ background: 'rgba(255, 255, 255, 0.03)', padding: 12, borderRadius: 10, textAlign: 'center' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)', textTransform: 'uppercase' }}>Streak</span>
            <div style={{ fontSize: '1.4rem', fontWeight: 800, color: '#f59e0b', marginTop: 2 }}>{student.streakDays} days</div>
          </div>
        </div>

        {/* Competencies Breakdown */}
        <div style={{ marginBottom: 24 }}>
          <h4 style={{ fontSize: '0.95rem', fontWeight: 700, marginBottom: 12 }}>Competencies Mastery Profile</h4>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {Object.entries(competencies).map(([concept, score]) => (
              <div 
                key={concept} 
                style={{ 
                  background: 'rgba(0, 0, 0, 0.2)', 
                  padding: '8px 12px', 
                  borderRadius: 8,
                  border: score < 60 ? '1px solid rgba(244, 63, 94, 0.3)' : '1px solid rgba(255, 255, 255, 0.05)'
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.78rem' }}>
                  <span style={{ color: '#e2e8f0' }}>{formatConcept(concept)}</span>
                  <strong style={{ color: score < 60 ? '#fb7185' : score >= 80 ? '#34d399' : '#fbbf24' }}>
                    {score}%
                  </strong>
                </div>
                <div className="progress-track" style={{ height: 4, marginTop: 6 }}>
                  <div 
                    className="progress-fill" 
                    style={{ 
                      width: `${score}%`, 
                      background: score >= 80 ? '#10b981' : score < 60 ? '#f43f5e' : '#f59e0b' 
                    }} 
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Button */}
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <button onClick={onClose} className="btn-secondary">
            Close
          </button>
          <button 
            onClick={() => {
              onClose();
              onIntervene(student);
            }} 
            className="btn-primary"
          >
            Assign Remedial Intervention
          </button>
        </div>
      </div>
    </div>
  );
}
