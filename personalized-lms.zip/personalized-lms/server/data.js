export const initialCourses = [
  {
    id: "cs-101",
    title: "Data Structures & Adaptive Algorithms",
    description: "Master foundational and advanced algorithms with dynamic difficulty calibration, interactive visualization, and concept-level mastery tracking.",
    instructor: "Dr. Evelyn Vance",
    category: "Computer Science",
    level: "Intermediate",
    thumbnail: "https://images.unsplash.com/photo-1516116211227-bbc0429c7886?w=600&auto=format&fit=crop&q=80",
    estimatedHours: 24,
    enrolledCount: 142,
    rating: 4.9,
    modules: [
      {
        id: "mod-1",
        title: "1. Arrays & Two-Pointer Strategies",
        duration: "4 hours",
        concepts: ["array-indexing", "two-pointers", "sliding-window"],
        lessons: [
          {
            id: "les-1-1",
            title: "Linear Memory & Contiguous Allocation",
            type: "reading",
            duration: "25 min",
            content: `### Understanding Arrays at the Hardware Level

Arrays are stored in contiguous memory blocks. This fundamental physical property allows \(O(1)\) index-based random access via memory address arithmetic:

$$\\text{Address}(A[i]) = \\text{BaseAddress} + (i \\times \\text{ElementSize})$$

#### Key Performance Trade-offs:
1. **Direct Access**: Instant lookup by index \(O(1)\).
2. **Insertion / Deletion at Head**: Shifts all \(n\) elements, incurring \(O(n)\) overhead.
3. **Cache Locality**: Contiguous storage leverages CPU L1/L2 cache prefetching drastically better than linked nodes.`,
            interactive: false
          },
          {
            id: "les-1-2",
            title: "Two-Pointer Strategy in Sorted Spaces",
            type: "interactive",
            duration: "35 min",
            content: `### Two-Pointer Strategy

When arrays are sorted or monotonic, two pointers converging from both boundaries eliminate quadratic \(O(n^2)\) loops and solve the problem in linear \(O(n)\) time.

#### Canonical Two-Sum Example:
Instead of nested loops comparing every pair, initialize:
- \`left = 0\`
- \`right = arr.length - 1\`
- If \`arr[left] + arr[right] == target\`, solution found!
- If the sum is too small, advance \`left++\` to increase magnitude.
- If the sum is too large, decrement \`right--\` to decrease magnitude.`,
            interactive: true,
            interactiveType: "two-pointer-visualizer"
          }
        ]
      },
      {
        id: "mod-2",
        title: "2. Recursion & Divide-and-Conquer",
        duration: "6 hours",
        concepts: ["recursion-base-case", "call-stack", "divide-and-conquer"],
        lessons: [
          {
            id: "les-2-1",
            title: "Anatomy of the Call Stack & Base Cases",
            type: "interactive",
            duration: "45 min",
            content: `### The Mechanics of Recursion

Every recursive function call pushes an activation frame onto the thread's execution call stack. Without a guaranteed **Base Case**, stack overflow occurs.

#### Three Laws of Recursion:
1. A recursive algorithm must have a base case.
2. A recursive algorithm must change its state and move toward the base case.
3. A recursive algorithm must call itself, recursively.`,
            interactive: true,
            interactiveType: "call-stack-simulator"
          },
          {
            id: "les-2-2",
            title: "Divide and Conquer: Merge Sort Mastery",
            type: "reading",
            duration: "40 min",
            content: `### Divide, Conquer, and Combine

Merge Sort splits an array in half until singletons remain, then merges sorted halves in \(O(n)\) time.

#### Master Theorem Recurrence:
$$T(n) = 2T(n/2) + O(n) \\implies O(n \\log n)$$

Guaranteed worst-case time complexity, stable sorting, ideal for linked lists and massive external memory buffers.`,
            interactive: false
          }
        ]
      },
      {
        id: "mod-3",
        title: "3. Binary Search Trees & Tree Traversals",
        duration: "7 hours",
        concepts: ["tree-traversal", "bst-properties", "tree-balancing"],
        lessons: [
          {
            id: "les-3-1",
            title: "In-Order, Pre-Order, and Level-Order Traversals",
            type: "interactive",
            duration: "50 min",
            content: `### Traversing Hierarchical Data

Unlike linear arrays, trees can be traversed in multiple orthogonal dimensions:
- **Depth-First Search (DFS)**: In-order (Left, Root, Right) gives sorted keys in a BST!
- **Breadth-First Search (BFS)**: Level-order using a FIFO Queue explores neighbor nodes layer by layer.`,
            interactive: true,
            interactiveType: "tree-visualizer"
          }
        ]
      },
      {
        id: "mod-4",
        title: "4. Dynamic Programming & Memoization",
        duration: "7 hours",
        concepts: ["memoization-caching", "overlapping-subproblems", "tabulation"],
        lessons: [
          {
            id: "les-4-1",
            title: "Overlapping Subproblems & Optimal Substructure",
            type: "interactive",
            duration: "60 min",
            content: `### Top-Down Memoization vs Bottom-Up Tabulation

Dynamic programming trades space for exponential time reduction.
By caching previously computed state tuples in a hash map or matrix, an \(O(2^n)\) brute force tree collapses to an \(O(n)\) or \(O(n \\cdot W)\) acyclic DAG traversal.`,
            interactive: true,
            interactiveType: "dp-matrix-visualizer"
          }
        ]
      }
    ]
  },
  {
    id: "web-201",
    title: "Modern React & Scalable Frontend Architecture",
    description: "Deep dive into component lifecycle, custom hooks, reactive state machines, and performance profiling for production web applications.",
    instructor: "Marcus Brody",
    category: "Web Development",
    level: "Intermediate",
    thumbnail: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=600&auto=format&fit=crop&q=80",
    estimatedHours: 18,
    enrolledCount: 215,
    rating: 4.8,
    modules: [
      {
        id: "web-mod-1",
        title: "1. Reactive State & Virtual DOM Reconciliation",
        duration: "4 hours",
        concepts: ["react-hooks", "virtual-dom", "state-management"],
        lessons: [
          {
            id: "web-les-1",
            title: "Fiber Tree & The Render Phase",
            type: "reading",
            duration: "30 min",
            content: `### React Fiber Architecture
React Fiber allows incremental rendering, pausing work, and prioritizing UI updates through cooperative multitasking and scheduling.`,
            interactive: false
          }
        ]
      },
      {
        id: "web-mod-2",
        title: "2. Custom Hooks & Side-Effect Synchronization",
        duration: "5 hours",
        concepts: ["custom-hooks", "use-effect-lifecycle", "memoization"],
        lessons: [
          {
            id: "web-les-2",
            title: "Hook Closures & Stale State Prevention",
            type: "interactive",
            duration: "45 min",
            content: `### Avoiding Stale State Closures
Hooks capture variables in their lexical scope during each render. Learn how ref callbacks and functional state updaters solve stale closures permanently.`,
            interactive: true,
            interactiveType: "hooks-sandbox"
          }
        ]
      }
    ]
  },
  {
    id: "ml-301",
    title: "Machine Learning Foundations & Neural Architectures",
    description: "Build adaptive mathematical intuition behind loss optimization, backpropagation, and transformer attention mechanisms.",
    instructor: "Dr. Evelyn Vance",
    category: "Artificial Intelligence",
    level: "Advanced",
    thumbnail: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=600&auto=format&fit=crop&q=80",
    estimatedHours: 32,
    enrolledCount: 98,
    rating: 4.95,
    modules: [
      {
        id: "ml-mod-1",
        title: "1. Gradient Descent & Loss Landscapes",
        duration: "6 hours",
        concepts: ["gradient-descent", "loss-functions", "convex-optimization"],
        lessons: [
          {
            id: "ml-les-1",
            title: "Vectorized Derivatives & Learning Rates",
            type: "interactive",
            duration: "50 min",
            content: `### Optimizing Parameters via Gradient Vectors
Understand why Adam optimizer with adaptive moment estimation outperforms vanilla stochastic gradient descent in non-convex loss surfaces.`,
            interactive: true,
            interactiveType: "gradient-descent-visualizer"
          }
        ]
      }
    ]
  }
];

export const initialQuestions = [
  // --- ARRAY & TWO-POINTER (Easy / Medium / Hard) ---
  {
    id: "q-arr-1",
    courseId: "cs-101",
    moduleId: "mod-1",
    conceptTag: "array-indexing",
    difficulty: "easy",
    difficultyWeight: 1,
    question: "Why does accessing an element by index in a contiguous array operate in O(1) constant time?",
    options: [
      "The memory addresses are calculated directly via formula: Base + (Index * ElementSize)",
      "The CPU performs a linear search from index 0 until the match is found",
      "Arrays automatically maintain an internal B-Tree index in RAM",
      "The compiler hashes every array index into a dynamic hash table"
    ],
    correctIndex: 0,
    hint: "Think about how physical RAM stores contiguous memory blocks and how base arithmetic works.",
    explanation: "Because an array occupies contiguous memory slots, the hardware calculates the direct byte address in one arithmetic cycle without needing traversal.",
    remedialLessonId: "les-1-1"
  },
  {
    id: "q-arr-2",
    courseId: "cs-101",
    moduleId: "mod-1",
    conceptTag: "two-pointers",
    difficulty: "medium",
    difficultyWeight: 2,
    question: "You have a sorted array and want to find if two numbers sum to target S. If arr[left] + arr[right] > S, what is the optimal pointer movement?",
    options: [
      "Increment left (left++) to test a larger number",
      "Decrement right (right--) because any number paired with current right will exceed S",
      "Reset left to 0 and shift right by 2",
      "Swap arr[left] and arr[right] in place"
    ],
    correctIndex: 1,
    hint: "Since the array is sorted, moving the right pointer inward decreases the sum.",
    explanation: "Because the array is in ascending order, arr[right] is the largest available element. Since even arr[left] + arr[right] > S, arr[right] cannot pair with any remaining candidate.",
    remedialLessonId: "les-1-2"
  },
  {
    id: "q-arr-3",
    courseId: "cs-101",
    moduleId: "mod-1",
    conceptTag: "sliding-window",
    difficulty: "hard",
    difficultyWeight: 3,
    question: "In the 'Longest Substring Without Repeating Characters' sliding window problem, what is the amortized time complexity when using a hash map to record last-seen character indices?",
    options: [
      "O(n^2) because each duplicate triggers a complete rewind of the left pointer",
      "O(n) because each character is visited at most twice as left and right pointers advance monotonically",
      "O(n log n) due to hash table rehashing at every iteration",
      "O(2^n) because the window expansion branches exponentially"
    ],
    correctIndex: 1,
    hint: "Observe that both pointers only move forward, never backwards.",
    explanation: "Both the left and right window pointers increment at most n times across the entire algorithm, yielding strict O(n) linear amortized complexity.",
    remedialLessonId: "les-1-2"
  },

  // --- RECURSION & BACKTRACKING (Easy / Medium / Hard) ---
  {
    id: "q-rec-1",
    courseId: "cs-101",
    moduleId: "mod-2",
    conceptTag: "recursion-base-case",
    difficulty: "easy",
    difficultyWeight: 1,
    question: "What catastrophic runtime failure occurs if a recursive function is called without a terminating base case?",
    options: [
      "Out of Memory / Call Stack Overflow error",
      "Memory Fragmentation error",
      "Deadlock condition",
      "Race condition in the event loop"
    ],
    correctIndex: 0,
    hint: "Each recursive call consumes a stack frame on the call stack until memory limit is breached.",
    explanation: "Without a base case, activation frames accumulate indefinitely on the call stack until available stack memory is exhausted, throwing a Stack Overflow.",
    remedialLessonId: "les-2-1"
  },
  {
    id: "q-rec-2",
    courseId: "cs-101",
    moduleId: "mod-2",
    conceptTag: "call-stack",
    difficulty: "medium",
    difficultyWeight: 2,
    question: "When evaluating Fibonacci recursively without memoization: fib(n) = fib(n-1) + fib(n-2), what is the maximum call stack depth and total time complexity?",
    options: [
      "Stack depth O(n), Time complexity O(2^n)",
      "Stack depth O(2^n), Time complexity O(n)",
      "Stack depth O(1), Time complexity O(n^2)",
      "Stack depth O(log n), Time complexity O(n log n)"
    ],
    correctIndex: 0,
    hint: "The stack depth corresponds to the maximum height of the recursion tree, while the total nodes represent work.",
    explanation: "The longest branch from fib(n) down to fib(1) has depth n, so stack space is O(n). However, the call tree branches into ~2^n nodes, resulting in O(2^n) exponential time.",
    remedialLessonId: "les-2-1"
  },
  {
    id: "q-rec-3",
    courseId: "cs-101",
    moduleId: "mod-2",
    conceptTag: "divide-and-conquer",
    difficulty: "hard",
    difficultyWeight: 3,
    question: "Why does QuickSort degrade to O(n^2) worst-case time complexity, and how does randomized pivot selection adaptively prevent this?",
    options: [
      "Degrades when already sorted and pivot is always extreme; randomization makes worst-case partitioning probability negligible (O(1/n!))",
      "Degrades due to merge operation overhead; randomization replaces merging with counting sort",
      "Degrades because recursion depth exceeds 64 frames; randomization forces iterative loops",
      "Degrades when array length is a prime number; randomization pads array length"
    ],
    correctIndex: 0,
    hint: "Think about unbalanced partitions such as 0 elements on one side and n-1 elements on the other.",
    explanation: "If the pivot consistently splits into sizes 0 and n-1, the recurrence is T(n) = T(n-1) + O(n) = O(n^2). Randomizing the pivot guarantees balanced expected partitions with O(n log n) runtime.",
    remedialLessonId: "les-2-2"
  },

  // --- TREE TRAVERSALS (Easy / Medium / Hard) ---
  {
    id: "q-tree-1",
    courseId: "cs-101",
    moduleId: "mod-3",
    conceptTag: "tree-traversal",
    difficulty: "easy",
    difficultyWeight: 1,
    question: "Which traversal of a valid Binary Search Tree (BST) yields the node values in strictly sorted ascending order?",
    options: [
      "In-Order Traversal (Left, Root, Right)",
      "Pre-Order Traversal (Root, Left, Right)",
      "Post-Order Traversal (Left, Right, Root)",
      "Level-Order Traversal (BFS)"
    ],
    correctIndex: 0,
    hint: "Recall BST property: all left descendants < root < all right descendants.",
    explanation: "By visiting Left subtree first, then Root, then Right subtree, In-Order traversal guarantees non-decreasing order for any BST.",
    remedialLessonId: "les-3-1"
  },
  {
    id: "q-tree-2",
    courseId: "cs-101",
    moduleId: "mod-3",
    conceptTag: "bst-properties",
    difficulty: "medium",
    difficultyWeight: 2,
    question: "Given a binary tree, what is the necessary and sufficient condition for a node to be valid under the BST invariant?",
    options: [
      "All nodes in its left subtree must be < node.val, and all nodes in its right subtree must be > node.val",
      "Only the immediate left child is < node.val and immediate right child is > node.val",
      "The root value must be the median of all child values",
      "Every leaf node must be at the exact same depth"
    ],
    correctIndex: 0,
    hint: "Checking only immediate children fails for subtle invalid trees where a distant left descendant exceeds the root.",
    explanation: "The BST invariant applies to entire subtrees, requiring every node in the left subtree to be strictly bounded within (min, root.val) and right subtree within (root.val, max).",
    remedialLessonId: "les-3-1"
  },
  {
    id: "q-tree-3",
    courseId: "cs-101",
    moduleId: "mod-3",
    conceptTag: "tree-balancing",
    difficulty: "hard",
    difficultyWeight: 3,
    question: "In an AVL tree or Red-Black Tree, why is self-balancing crucial after inserting sequential sorted items?",
    options: [
      "Without rebalancing, sequential insertions degrade the BST into a degenerate linear linked list with O(n) search time",
      "Without rebalancing, the binary tree would consume 4x more pointer memory",
      "Balancing prevents hash collisions in the node keys",
      "Balancing is only needed for multi-threaded access locks"
    ],
    correctIndex: 0,
    hint: "Picture inserting 1, 2, 3, 4, 5 in order into an unbalanced tree.",
    explanation: "Without rotations, inserting sorted elements creates a single right-skewed stick of height n, destroying logarithmic O(log n) efficiency and causing O(n) lookups.",
    remedialLessonId: "les-3-1"
  },

  // --- DYNAMIC PROGRAMMING (Easy / Medium / Hard) ---
  {
    id: "q-dp-1",
    courseId: "cs-101",
    moduleId: "mod-4",
    conceptTag: "overlapping-subproblems",
    difficulty: "easy",
    difficultyWeight: 1,
    question: "What fundamental property must a problem possess to make Dynamic Programming applicable instead of Greedy algorithms?",
    options: [
      "Optimal Substructure and Overlapping Subproblems",
      "Sorted input elements and zero recursion depth",
      "Continuous real-number inputs and linear equations",
      "Deterministic finite automaton state transitions"
    ],
    correctIndex: 0,
    hint: "DP saves computational work because identical states are solved repeatedly.",
    explanation: "Dynamic Programming requires: (1) Optimal substructure (optimal solution composed of optimal solutions to subproblems), and (2) Overlapping subproblems (same subproblems solved multiple times).",
    remedialLessonId: "les-4-1"
  },
  {
    id: "q-dp-2",
    courseId: "cs-101",
    moduleId: "mod-4",
    conceptTag: "memoization-caching",
    difficulty: "medium",
    difficultyWeight: 2,
    question: "What distinguishes Top-Down DP with Memoization from Bottom-Up DP with Tabulation?",
    options: [
      "Top-Down uses recursion + cache on demand; Bottom-Up iteratively fills a table in topological order avoiding recursion overhead",
      "Top-Down is O(n!) while Bottom-Up is always O(1)",
      "Top-Down only works for graphs; Bottom-Up only works for arrays",
      "Bottom-Up requires exponential stack memory"
    ],
    correctIndex: 0,
    hint: "Consider how states are computed: lazy recursive evaluation vs structured iterative loops.",
    explanation: "Top-Down evaluates subproblems lazily via recursion and stores answers in a memo lookup table. Bottom-Up computes all states iteratively from base cases up, saving recursion stack frames.",
    remedialLessonId: "les-4-1"
  },
  {
    id: "q-dp-3",
    courseId: "cs-101",
    moduleId: "mod-4",
    conceptTag: "tabulation",
    difficulty: "hard",
    difficultyWeight: 3,
    question: "In the 0/1 Knapsack Problem with N items and Capacity W, how can the 2D DP table dp[i][w] be optimized from O(N * W) space down to O(W) space?",
    options: [
      "By using a 1D array dp[w] and traversing the capacity w backwards from W down to item weight",
      "By sorting items by weight-to-value ratio and using binary search",
      "By pruning weights that are multiples of 2",
      "By replacing the table with a randomized Bloom filter"
    ],
    correctIndex: 0,
    hint: "Traversing backwards ensures you reference values from the previous item (i-1) without overwriting them prematurely.",
    explanation: "Because dp[i][w] only depends on dp[i-1][w] and dp[i-1][w - weight[i]], iterating capacity backwards prevents the same item from being counted more than once in 1D space.",
    remedialLessonId: "les-4-1"
  }
];

export const initialStudents = [
  {
    id: "student-alex",
    name: "Alex Chen",
    email: "alex.chen@university.edu",
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
    role: "student",
    preferredLearningStyle: "visual", // 'visual', 'practical', 'theoretical'
    dailyGoalMinutes: 30,
    streakDays: 6,
    lastActiveDate: "2026-10-07",
    engagementScore: 78, // 0-100
    overallMastery: 72, // 0-100
    competencies: {
      "array-indexing": 92,
      "two-pointers": 85,
      "sliding-window": 75,
      "recursion-base-case": 54, // Stumbling block
      "call-stack": 58,
      "divide-and-conquer": 62,
      "tree-traversal": 88,
      "bst-properties": 80,
      "tree-balancing": 60,
      "overlapping-subproblems": 55,
      "memoization-caching": 48, // Remedial need!
      "tabulation": 50
    },
    enrolledCourses: [
      {
        courseId: "cs-101",
        progressPercent: 65,
        completedLessonIds: ["les-1-1", "les-1-2", "les-2-1"],
        currentModuleId: "mod-2",
        quizzesTaken: 4,
        averageQuizScore: 71
      },
      {
        courseId: "web-201",
        progressPercent: 40,
        completedLessonIds: ["web-les-1"],
        currentModuleId: "web-mod-1",
        quizzesTaken: 1,
        averageQuizScore: 84
      }
    ],
    quizHistory: [
      {
        quizId: "attempt-101",
        courseId: "cs-101",
        timestamp: "2026-10-05T14:30:00Z",
        score: 75,
        masteryChange: "+4%",
        questionsAnswered: 5,
        difficultyTrajectory: ["medium", "hard", "medium", "medium", "hard"],
        weakConceptsIdentified: ["recursion-base-case"]
      },
      {
        quizId: "attempt-102",
        courseId: "cs-101",
        timestamp: "2026-10-07T11:20:00Z",
        score: 60,
        masteryChange: "-2%",
        questionsAnswered: 5,
        difficultyTrajectory: ["medium", "easy", "easy", "medium", "easy"],
        weakConceptsIdentified: ["memoization-caching", "call-stack"]
      }
    ],
    badges: [
      { id: "b1", title: "Array Master", icon: "⚡", description: "Demonstrated >90% mastery on linear data structures" },
      { id: "b2", title: "6-Day Streak", icon: "🔥", description: "Studied consecutively for nearly a full week" }
    ]
  },
  {
    id: "student-maria",
    name: "Maria Garcia",
    email: "maria.g@university.edu",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
    role: "student",
    preferredLearningStyle: "practical",
    dailyGoalMinutes: 45,
    streakDays: 14,
    lastActiveDate: "2026-10-07",
    engagementScore: 94,
    overallMastery: 89,
    competencies: {
      "array-indexing": 95,
      "two-pointers": 92,
      "sliding-window": 90,
      "recursion-base-case": 88,
      "call-stack": 86,
      "divide-and-conquer": 85,
      "tree-traversal": 94,
      "bst-properties": 90,
      "tree-balancing": 82,
      "overlapping-subproblems": 85,
      "memoization-caching": 82,
      "tabulation": 80
    },
    enrolledCourses: [
      {
        courseId: "cs-101",
        progressPercent: 90,
        completedLessonIds: ["les-1-1", "les-1-2", "les-2-1", "les-2-2", "les-3-1"],
        currentModuleId: "mod-4",
        quizzesTaken: 6,
        averageQuizScore: 91
      }
    ],
    quizHistory: [
      {
        quizId: "attempt-201",
        courseId: "cs-101",
        timestamp: "2026-10-06T18:00:00Z",
        score: 95,
        masteryChange: "+6%",
        questionsAnswered: 5,
        difficultyTrajectory: ["medium", "hard", "hard", "hard", "hard"],
        weakConceptsIdentified: []
      }
    ],
    badges: [
      { id: "b1", title: "Algorithmic Prodigy", icon: "🏆", description: "Solved 4 consecutive hard-tier questions without hints" },
      { id: "b2", title: "Fortnight Fire", icon: "🔥", description: "14 consecutive active learning days" },
      { id: "b3", title: "Tree Whisperer", icon: "🌳", description: "Flawless score on BST Traversals" }
    ]
  },
  {
    id: "student-jordan",
    name: "Jordan Lee",
    email: "jordan.lee@university.edu",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
    role: "student",
    preferredLearningStyle: "theoretical",
    dailyGoalMinutes: 20,
    streakDays: 1,
    lastActiveDate: "2026-10-02",
    engagementScore: 36, // At Risk!
    overallMastery: 46, // At Risk!
    competencies: {
      "array-indexing": 65,
      "two-pointers": 50,
      "sliding-window": 42,
      "recursion-base-case": 38,
      "call-stack": 40,
      "divide-and-conquer": 45,
      "tree-traversal": 48,
      "bst-properties": 42,
      "tree-balancing": 35,
      "overlapping-subproblems": 30,
      "memoization-caching": 32,
      "tabulation": 30
    },
    enrolledCourses: [
      {
        courseId: "cs-101",
        progressPercent: 25,
        completedLessonIds: ["les-1-1"],
        currentModuleId: "mod-1",
        quizzesTaken: 2,
        averageQuizScore: 48
      }
    ],
    quizHistory: [
      {
        quizId: "attempt-301",
        courseId: "cs-101",
        timestamp: "2026-10-02T09:15:00Z",
        score: 45,
        masteryChange: "-5%",
        questionsAnswered: 4,
        difficultyTrajectory: ["medium", "easy", "easy", "easy"],
        weakConceptsIdentified: ["array-indexing", "recursion-base-case"]
      }
    ],
    badges: [
      { id: "b1", title: "First Step", icon: "🌱", description: "Completed initial diagnostic evaluation" }
    ]
  }
];

export const initialInstructor = {
  id: "inst-dr-vance",
  name: "Dr. Evelyn Vance",
  title: "Professor of Computer Science & Learning Systems Lead",
  department: "Department of Intelligent Systems",
  avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80"
};
