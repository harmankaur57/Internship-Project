import React, { useState } from 'react';
import { GitCommit, Play, RotateCcw } from 'lucide-react';

export default function TreeVisualizer() {
  const [traversalType, setTraversalType] = useState('inorder');
  const [currentStep, setCurrentStep] = useState(0);

  // BST Structure:
  //         10
  //       /    \
  //      5      15
  //     / \       \
  //    2   7       20

  const sequences = {
    inorder: {
      name: "In-Order (Left, Root, Right) -> Yields Sorted Order",
      steps: [2, 5, 7, 10, 15, 20],
      note: "Notice how visiting Left-Subtree -> Root -> Right-Subtree naturally extracts keys in monotonic ascending order!"
    },
    preorder: {
      name: "Pre-Order (Root, Left, Right) -> Useful for Serialization",
      steps: [10, 5, 2, 7, 15, 20],
      note: "Visits the parent before its children, preserving hierarchical tree layout for deep copying or serialization."
    },
    levelorder: {
      name: "Level-Order (Breadth-First Queue) -> Layer by Layer",
      steps: [10, 5, 15, 2, 7, 20],
      note: "Uses a FIFO Queue to sweep breadth-first across each tree depth level."
    }
  };

  const activeSequence = sequences[traversalType];
  const activeNodeVal = activeSequence.steps[currentStep];
  const visitedNodes = activeSequence.steps.slice(0, currentStep + 1);

  const reset = (newType) => {
    if (newType) setTraversalType(newType);
    setCurrentStep(0);
  };

  const stepNext = () => {
    if (currentStep < activeSequence.steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const renderNode = (val, x, y, isRoot = false) => {
    const isCurrent = val === activeNodeVal;
    const isVisited = visitedNodes.includes(val);

    return (
      <g key={val} transform={`translate(${x}, ${y})`}>
        <circle
          r="22"
          fill={isCurrent ? '#6366f1' : isVisited ? 'rgba(16, 185, 129, 0.25)' : '#111a2e'}
          stroke={isCurrent ? '#818cf8' : isVisited ? '#10b981' : 'rgba(255, 255, 255, 0.2)'}
          strokeWidth={isCurrent ? '3' : '2'}
          style={{
            filter: isCurrent ? 'drop-shadow(0 0 10px rgba(99, 102, 241, 0.8))' : 'none',
            transition: 'all 0.3s ease'
          }}
        />
        <text
          textAnchor="middle"
          dy="6"
          fill="#ffffff"
          fontSize="14"
          fontWeight="bold"
          fontFamily="var(--font-mono)"
        >
          {val}
        </text>
        {isRoot && (
          <text textAnchor="middle" dy="-28" fill="var(--text-dim)" fontSize="10" fontWeight="600">
            ROOT
          </text>
        )}
      </g>
    );
  };

  return (
    <div className="visualizer-container">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <div>
          <span className="badge badge-accent" style={{ marginBottom: 4 }}>Binary Search Tree Explorer</span>
          <h4 style={{ fontSize: '1.1rem', fontWeight: 700 }}>Interactive Tree Traversal Simulator</h4>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
            Compare In-Order vs Pre-Order vs Level-Order traversal invariants.
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <select 
            value={traversalType} 
            onChange={e => reset(e.target.value)}
            style={{ padding: '6px 12px' }}
          >
            <option value="inorder">In-Order Traversal (L-Root-R)</option>
            <option value="preorder">Pre-Order Traversal (Root-L-R)</option>
            <option value="levelorder">Level-Order (BFS Queue)</option>
          </select>
          <button onClick={() => reset()} className="btn-secondary" style={{ padding: '6px 12px', fontSize: '0.8rem' }}>
            <RotateCcw size={14} /> Reset
          </button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 20 }}>
        {/* SVG Tree Diagram */}
        <div 
          style={{ 
            background: '#070b14', 
            borderRadius: 12, 
            display: 'flex', 
            justifyContent: 'center', 
            alignItems: 'center',
            padding: 16,
            border: '1px solid rgba(255, 255, 255, 0.05)'
          }}
        >
          <svg width="400" height="230" viewBox="0 0 400 230">
            {/* Tree Branch Edges */}
            <line x1="200" y1="45" x2="100" y2="105" stroke="rgba(255, 255, 255, 0.15)" strokeWidth="2" />
            <line x1="200" y1="45" x2="300" y2="105" stroke="rgba(255, 255, 255, 0.15)" strokeWidth="2" />
            <line x1="100" y1="105" x2="50" y2="175" stroke="rgba(255, 255, 255, 0.15)" strokeWidth="2" />
            <line x1="100" y1="105" x2="150" y2="175" stroke="rgba(255, 255, 255, 0.15)" strokeWidth="2" />
            <line x1="300" y1="105" x2="350" y2="175" stroke="rgba(255, 255, 255, 0.15)" strokeWidth="2" />

            {/* Tree Nodes */}
            {renderNode(10, 200, 45, true)}
            {renderNode(5, 100, 105)}
            {renderNode(15, 300, 105)}
            {renderNode(2, 50, 175)}
            {renderNode(7, 150, 175)}
            {renderNode(20, 350, 175)}
          </svg>
        </div>

        {/* Traversal State & Output Array */}
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>
              OUTPUT VISITED LIST
            </span>
            <div 
              style={{
                display: 'flex',
                gap: 6,
                flexWrap: 'wrap',
                marginTop: 8,
                padding: 10,
                background: '#090e17',
                borderRadius: 8,
                minHeight: 48,
                border: '1px solid var(--border-subtle)'
              }}
            >
              {visitedNodes.map((val, idx) => (
                <span
                  key={idx}
                  style={{
                    padding: '4px 8px',
                    borderRadius: 6,
                    background: val === activeNodeVal ? '#6366f1' : 'rgba(16, 185, 129, 0.2)',
                    color: '#ffffff',
                    fontFamily: 'var(--font-mono)',
                    fontWeight: 700,
                    fontSize: '0.85rem'
                  }}
                >
                  {val}
                </span>
              ))}
            </div>

            <div style={{ marginTop: 14, fontSize: '0.82rem', color: 'var(--text-muted)' }}>
              {activeSequence.note}
            </div>
          </div>

          <button
            onClick={stepNext}
            disabled={currentStep >= activeSequence.steps.length - 1}
            className="btn-primary"
            style={{ width: '100%', opacity: currentStep >= activeSequence.steps.length - 1 ? 0.5 : 1 }}
          >
            <Play size={16} /> 
            {currentStep >= activeSequence.steps.length - 1 ? "Traversal Complete" : "Advance Next Node"}
          </button>
        </div>
      </div>
    </div>
  );
}
