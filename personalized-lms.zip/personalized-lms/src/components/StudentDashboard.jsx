import React from 'react';
import { 
  Award, 
  BookOpen, 
  Zap, 
  Flame, 
  TrendingUp, 
  AlertCircle, 
  CheckCircle, 
  Clock, 
  ArrowRight, 
  Eye, 
  Code, 
  BookMarked,
  Activity
} from 'lucide-react';

export default function StudentDashboard({ 
  student, 
  courses, 
  recommendations, 
  onNavigateTab, 
  onSelectCourse, 
  onStartQuiz, 
  onUpdateLearningStyle 
}) {
  if (!student) return null;

  const primaryRecommendation = recommendations && recommendations.length > 0 ? recommendations[0] : null;

  // Find lowest concept
  const weakConcepts = Object.entries(student.competencies || {})
    .filter(([_, score]) => score < 65)
    .sort((a, b) => a[1] - b[1]);

  const enrolledCourseObjects = courses.filter(c => 
    student.enrolledCourses.some(e => e.courseId === c.id)
  );

  return (
    <div style={{ maxWidth: 1300, margin: '0 auto', padding: '32px 24px', display: 'flex', flexDirection: 'column', gap: 28 }}>
      
      {/* Top Welcome & Learning Style Configuration */}
      <div 
        className="glass-panel" 
        style={{ 
          padding: '24px 28px', 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: 16
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <img 
            src={student.avatar} 
            alt={student.name} 
            style={{ width: 64, height: 64, borderRadius: '50%', border: '2px solid var(--accent-primary)', objectFit: 'cover' }} 
          />
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <h2 style={{ fontSize: '1.5rem', fontWeight: 800 }}>Welcome back, {student.name}!</h2>
              <span 
                className="badge" 
                style={{
                  background: student.engagementScore >= 80 ? 'var(--status-success-bg)' : student.engagementScore < 50 ? 'var(--status-danger-bg)' : 'var(--status-warning-bg)',
                  color: student.engagementScore >= 80 ? '#34d399' : student.engagementScore < 50 ? '#fb7185' : '#fbbf24',
                  border: '1px solid currentColor'
                }}
              >
                {student.engagementScore >= 80 ? '🟢 Highly Engaged' : student.engagementScore < 50 ? '⚠️ High Drop-off Risk' : '🟡 Moderate Engagement'}
              </span>
            </div>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginTop: 4 }}>
              Adaptive engine calibrated to your individual learning velocity and concept retention index.
            </p>
          </div>
        </div>

        {/* Adaptive Learning Style Preference Selector */}
        <div style={{ background: 'rgba(255, 255, 255, 0.04)', padding: '12px 16px', borderRadius: 12, border: '1px solid var(--border-subtle)' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)', textTransform: 'uppercase', fontWeight: 700 }}>
            Active Learning Modality
          </span>
          <div style={{ display: 'flex', gap: 8, marginTop: 6 }}>
            {[
              { id: 'visual', label: 'Visual & Interactive', icon: Eye },
              { id: 'practical', label: 'Hands-on Code', icon: Code },
              { id: 'theoretical', label: 'Theory & Proofs', icon: BookMarked }
            ].map(style => {
              const Icon = style.icon;
              const isActive = student.preferredLearningStyle === style.id;
              return (
                <button
                  key={style.id}
                  onClick={() => onUpdateLearningStyle(style.id)}
                  style={{
                    padding: '6px 12px',
                    borderRadius: 8,
                    fontSize: '0.8rem',
                    fontWeight: 600,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    background: isActive ? 'rgba(99, 102, 241, 0.25)' : 'transparent',
                    border: isActive ? '1px solid #818cf8' : '1px solid transparent',
                    color: isActive ? '#ffffff' : 'var(--text-muted)'
                  }}
                >
                  <Icon size={14} /> {style.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 4 Core Metric KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 20 }}>
        
        {/* Metric 1: Overall Mastery */}
        <div className="glass-panel" style={{ padding: 20, position: 'relative', overflow: 'hidden' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>
              Concept Mastery Index
            </span>
            <Award size={20} color="#818cf8" />
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 10 }}>
            <span style={{ fontSize: '2.2rem', fontWeight: 800, color: '#ffffff' }}>
              {student.overallMastery}%
            </span>
            <span style={{ fontSize: '0.85rem', color: student.overallMastery >= 80 ? '#34d399' : student.overallMastery < 50 ? '#fb7185' : '#fbbf24', fontWeight: 600 }}>
              {student.overallMastery >= 80 ? 'Proficient' : student.overallMastery < 50 ? 'Emerging' : 'Competent'}
            </span>
          </div>
          <div className="progress-track" style={{ marginTop: 12 }}>
            <div 
              className="progress-fill" 
              style={{ 
                width: `${student.overallMastery}%`, 
                background: student.overallMastery >= 80 ? 'linear-gradient(90deg, #10b981, #06b6d4)' : 'linear-gradient(90deg, #f59e0b, #6366f1)' 
              }} 
            />
          </div>
        </div>

        {/* Metric 2: Engagement Index */}
        <div className="glass-panel" style={{ padding: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>
              Engagement Score
            </span>
            <Activity size={20} color="#38bdf8" />
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 10 }}>
            <span style={{ fontSize: '2.2rem', fontWeight: 800, color: '#ffffff' }}>
              {student.engagementScore}
            </span>
            <span style={{ fontSize: '0.85rem', color: 'var(--text-dim)' }}>/ 100</span>
          </div>
          <div className="progress-track" style={{ marginTop: 12 }}>
            <div 
              className="progress-fill" 
              style={{ 
                width: `${student.engagementScore}%`, 
                background: student.engagementScore >= 75 ? '#38bdf8' : student.engagementScore < 50 ? '#f43f5e' : '#f59e0b' 
              }} 
            />
          </div>
        </div>

        {/* Metric 3: Learning Streak */}
        <div className="glass-panel" style={{ padding: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>
              Daily Learning Streak
            </span>
            <Flame size={20} color="#f59e0b" className="pulse-fire" />
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 10 }}>
            <span style={{ fontSize: '2.2rem', fontWeight: 800, color: '#f59e0b' }}>
              {student.streakDays}
            </span>
            <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>consecutive days</span>
          </div>
          <p style={{ fontSize: '0.75rem', color: 'var(--text-dim)', marginTop: 10 }}>
            Daily goal: {student.dailyGoalMinutes} min/day
          </p>
        </div>

        {/* Metric 4: Diagnostic Quizzes Completed */}
        <div className="glass-panel" style={{ padding: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>
              Adaptive Assessments
            </span>
            <Zap size={20} color="#c084fc" />
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 10 }}>
            <span style={{ fontSize: '2.2rem', fontWeight: 800, color: '#ffffff' }}>
              {student.quizHistory?.length || 0}
            </span>
            <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>sessions completed</span>
          </div>
          <button 
            onClick={() => onNavigateTab('quiz')}
            style={{ fontSize: '0.78rem', color: '#a5b4fc', marginTop: 10, display: 'flex', alignItems: 'center', gap: 4, fontWeight: 600 }}
          >
            Start Dynamic Session <ArrowRight size={14} />
          </button>
        </div>
      </div>

      {/* Hero Recommendation Banner: "Next Best Action" */}
      {primaryRecommendation && (
        <div 
          className="glass-panel"
          style={{
            padding: '24px 28px',
            background: 'linear-gradient(135deg, rgba(99, 102, 241, 0.15) 0%, rgba(6, 182, 212, 0.12) 100%)',
            border: '1px solid rgba(99, 102, 241, 0.3)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: 20
          }}
        >
          <div style={{ maxWidth: 750 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
              <span className="badge badge-accent">
                {primaryRecommendation.badge}
              </span>
              <span style={{ fontSize: '0.78rem', color: '#93c5fd' }}>
                💡 {primaryRecommendation.reason}
              </span>
            </div>
            <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#ffffff' }}>
              {primaryRecommendation.title}
            </h3>
            <p style={{ color: '#cbd5e1', fontSize: '0.9rem', marginTop: 4 }}>
              {primaryRecommendation.description}
            </p>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginTop: 10, fontSize: '0.8rem', color: 'var(--text-muted)' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                <Clock size={14} /> Est. {primaryRecommendation.estimatedMinutes} mins
              </span>
              <span>•</span>
              <span style={{ color: '#67e8f9' }}>
                {primaryRecommendation.modalityMatch}
              </span>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 10 }}>
            <button 
              onClick={() => {
                if (primaryRecommendation.type === 'accelerated') {
                  onStartQuiz(primaryRecommendation.courseId, primaryRecommendation.moduleId);
                } else {
                  onSelectCourse(primaryRecommendation.courseId, primaryRecommendation.lessonId);
                }
              }}
              className="btn-primary"
              style={{ padding: '12px 24px', fontSize: '0.95rem' }}
            >
              <Zap size={18} /> {primaryRecommendation.actionText}
            </button>
            <button 
              onClick={() => onNavigateTab('recommendations')} 
              className="btn-secondary"
            >
              All AI Suggestions
            </button>
          </div>
        </div>
      )}

      {/* Weak Concept Stumbling Block Alert (if any) */}
      {weakConcepts.length > 0 && (
        <div 
          className="glass-panel" 
          style={{ 
            padding: '20px 24px', 
            border: '1px solid rgba(244, 63, 94, 0.25)', 
            background: 'rgba(244, 63, 94, 0.05)' 
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
            <AlertCircle size={20} color="#fb7185" />
            <h4 style={{ fontSize: '1rem', fontWeight: 700, color: '#fb7185' }}>
              Concept Diagnostic Notice: Foundational Gaps Detected
            </h4>
          </div>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: 16 }}>
            The adaptive engine identified concept retention below 65%. Strengthening these will unlock higher tiers in adaptive quizzes.
          </p>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            {weakConcepts.map(([concept, score]) => (
              <div 
                key={concept}
                style={{
                  background: 'rgba(0, 0, 0, 0.3)',
                  border: '1px solid rgba(244, 63, 94, 0.2)',
                  borderRadius: 10,
                  padding: '10px 14px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 12
                }}
              >
                <div>
                  <div style={{ fontWeight: 700, fontSize: '0.85rem', color: '#ffffff' }}>
                    {concept.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                  </div>
                  <div style={{ fontSize: '0.75rem', color: '#fb7185', fontWeight: 600 }}>
                    Mastery: {score}%
                  </div>
                </div>
                <button
                  onClick={() => onSelectCourse('cs-101', 'les-2-1')}
                  className="btn-danger"
                  style={{ fontSize: '0.75rem', padding: '6px 10px' }}
                >
                  Review Byte
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Enrolled Courses Progress */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>Enrolled Learning Tracks</h3>
          <button 
            onClick={() => onNavigateTab('courses')} 
            style={{ fontSize: '0.85rem', color: 'var(--accent-primary)', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}
          >
            Explore Catalog <ArrowRight size={14} />
          </button>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 20 }}>
          {enrolledCourseObjects.map(course => {
            const enrollment = student.enrolledCourses.find(e => e.courseId === course.id);
            const progress = enrollment?.progressPercent || 0;

            return (
              <div 
                key={course.id} 
                className="glass-panel glass-panel-interactive" 
                style={{ padding: 22, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}
              >
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                    <span className="badge badge-accent">{course.category}</span>
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>{course.level}</span>
                  </div>
                  <h4 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#ffffff' }}>{course.title}</h4>
                  <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: 6, lineClamp: 2 }}>
                    {course.description}
                  </p>
                </div>

                <div style={{ marginTop: 20 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: 6 }}>
                    <span style={{ color: 'var(--text-dim)' }}>Syllabus Progress</span>
                    <span style={{ fontWeight: 700, color: '#38bdf8' }}>{progress}%</span>
                  </div>
                  <div className="progress-track">
                    <div 
                      className="progress-fill" 
                      style={{ width: `${progress}%`, background: 'linear-gradient(90deg, #6366f1, #06b6d4)' }} 
                    />
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 16 }}>
                    <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                      {enrollment?.completedLessonIds?.length || 0} lessons completed
                    </span>
                    <button 
                      onClick={() => onSelectCourse(course.id)} 
                      className="btn-primary"
                      style={{ padding: '8px 16px', fontSize: '0.85rem' }}
                    >
                      Continue <ArrowRight size={14} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
}
