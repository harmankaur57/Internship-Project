import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar.jsx';
import StudentDashboard from './components/StudentDashboard.jsx';
import CourseCatalog from './components/CourseCatalog.jsx';
import CourseViewer from './components/CourseViewer.jsx';
import AdaptiveQuiz from './components/AdaptiveQuiz.jsx';
import ProgressAnalytics from './components/ProgressAnalytics.jsx';
import RecommendationsView from './components/RecommendationsView.jsx';
import InstructorDashboard from './components/InstructorDashboard.jsx';

export default function App() {
  const [students, setStudents] = useState([]);
  const [courses, setCourses] = useState([]);
  const [activeStudent, setActiveStudent] = useState(null);
  const [recommendations, setRecommendations] = useState([]);
  const [activeTab, setActiveTab] = useState('dashboard');
  
  // Navigation props for deep linking
  const [activeCourseId, setActiveCourseId] = useState('cs-101');
  const [activeLessonId, setActiveLessonId] = useState(null);
  const [quizCourseId, setQuizCourseId] = useState('cs-101');
  const [quizModuleId, setQuizModuleId] = useState(null);

  const [loading, setLoading] = useState(true);

  // Determine current role based on activeTab
  const currentRole = activeTab.startsWith('instructor') ? 'instructor' : 'student';

  // Load initial data
  const loadData = async () => {
    try {
      setLoading(true);
      // Fetch students
      const studRes = await fetch('/api/students');
      const studData = await studRes.json();
      if (studData.success && studData.students.length > 0) {
        setStudents(studData.students);
        // Retain current or set first
        const currentId = activeStudent ? activeStudent.id : studData.students[0].id;
        const matched = studData.students.find(s => s.id === currentId) || studData.students[0];
        setActiveStudent(matched);

        // Fetch courses for this student
        const crsRes = await fetch(`/api/courses?studentId=${matched.id}`);
        const crsData = await crsRes.json();
        if (crsData.success) {
          setCourses(crsData.courses);
        }

        // Fetch recommendations for this student
        const recRes = await fetch(`/api/recommendations/${matched.id}`);
        const recData = await recRes.json();
        if (recData.success) {
          setRecommendations(recData.recommendations);
        }
      }
    } catch (err) {
      console.error('Failed to load LMS data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // When active student changes, refresh their courses and recommendations
  const handleStudentChange = async (student) => {
    setActiveStudent(student);
    try {
      const crsRes = await fetch(`/api/courses?studentId=${student.id}`);
      const crsData = await crsRes.json();
      if (crsData.success) setCourses(crsData.courses);

      const recRes = await fetch(`/api/recommendations/${student.id}`);
      const recData = await recRes.json();
      if (recData.success) setRecommendations(recData.recommendations);
    } catch (err) {
      console.error(err);
    }
  };

  // Reset to seed data
  const handleResetData = async () => {
    try {
      await fetch('/api/reset', { method: 'POST' });
      await loadData();
    } catch (err) {
      console.error('Reset failed:', err);
    }
  };

  // Update student learning modality preference
  const handleUpdateLearningStyle = async (newStyle) => {
    if (!activeStudent) return;
    try {
      const res = await fetch(`/api/students/${activeStudent.id}/preferences`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ preferredLearningStyle: newStyle })
      });
      const data = await res.json();
      if (data.success) {
        setActiveStudent(data.student);
        // Refresh recommendations reflecting new modality
        const recRes = await fetch(`/api/recommendations/${activeStudent.id}`);
        const recData = await recRes.json();
        if (recData.success) setRecommendations(recData.recommendations);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Complete a lesson
  const handleCompleteLesson = async (courseId, lessonId, minutes) => {
    if (!activeStudent) return;
    try {
      const res = await fetch(`/api/students/${activeStudent.id}/lessons/complete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ courseId, lessonId, timeSpentMinutes: minutes })
      });
      const data = await res.json();
      if (data.success) {
        setActiveStudent(data.student);
        // Refresh courses
        const crsRes = await fetch(`/api/courses?studentId=${activeStudent.id}`);
        const crsData = await crsRes.json();
        if (crsData.success) setCourses(crsData.courses);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Navigation callbacks
  const handleSelectCourse = (courseId, lessonId = null) => {
    setActiveCourseId(courseId);
    setActiveLessonId(lessonId);
    setActiveTab('viewer');
  };

  const handleStartQuiz = (courseId, moduleId = null) => {
    setQuizCourseId(courseId);
    setQuizModuleId(moduleId);
    setActiveTab('quiz');
  };

  const activeCourse = courses.find(c => c.id === activeCourseId) || courses[0];

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Navbar
        currentRole={currentRole}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeStudent={activeStudent}
        setActiveStudent={handleStudentChange}
        students={students}
        onResetData={handleResetData}
      />

      <main style={{ flex: 1, paddingBottom: 60 }}>
        {loading && !activeStudent ? (
          <div style={{ textAlign: 'center', padding: '100px 20px', color: 'var(--text-muted)' }}>
            <div style={{ fontSize: '1.2rem', fontWeight: 600 }}>Initializing Adaptive Engine...</div>
          </div>
        ) : (
          <>
            {activeTab === 'dashboard' && (
              <StudentDashboard
                student={activeStudent}
                courses={courses}
                recommendations={recommendations}
                onNavigateTab={setActiveTab}
                onSelectCourse={handleSelectCourse}
                onStartQuiz={handleStartQuiz}
                onUpdateLearningStyle={handleUpdateLearningStyle}
              />
            )}

            {activeTab === 'courses' && (
              <CourseCatalog
                courses={courses}
                student={activeStudent}
                onSelectCourse={handleSelectCourse}
                onStartQuiz={handleStartQuiz}
              />
            )}

            {activeTab === 'viewer' && activeCourse && (
              <CourseViewer
                course={activeCourse}
                student={activeStudent}
                initialLessonId={activeLessonId}
                onBack={() => setActiveTab('courses')}
                onStartQuiz={handleStartQuiz}
                onCompleteLesson={handleCompleteLesson}
              />
            )}

            {activeTab === 'quiz' && (
              <AdaptiveQuiz
                student={activeStudent}
                courses={courses}
                preselectedCourseId={quizCourseId}
                preselectedModuleId={quizModuleId}
                onQuizFinished={(updatedStudent) => {
                  setActiveStudent(updatedStudent);
                  loadData();
                }}
                onGoToLesson={(cId, lId) => handleSelectCourse(cId, lId)}
              />
            )}

            {activeTab === 'analytics' && (
              <ProgressAnalytics
                student={activeStudent}
                onGoToLesson={(cId, lId) => handleSelectCourse(cId, lId)}
              />
            )}

            {activeTab === 'recommendations' && (
              <RecommendationsView
                student={activeStudent}
                recommendations={recommendations}
                onSelectCourse={handleSelectCourse}
                onStartQuiz={handleStartQuiz}
                onUpdateLearningStyle={handleUpdateLearningStyle}
              />
            )}

            {(activeTab === 'instructor-cohort' || activeTab === 'instructor-curriculum') && (
              <InstructorDashboard
                courses={courses}
                students={students}
                activeSubTab={activeTab === 'instructor-curriculum' ? 'curriculum' : 'cohort'}
                onRefreshData={loadData}
              />
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer 
        style={{
          borderTop: '1px solid var(--border-subtle)',
          padding: '20px 24px',
          textAlign: 'center',
          fontSize: '0.8rem',
          color: 'var(--text-dim)',
          background: 'rgba(10, 15, 29, 0.7)'
        }}
      >
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
          <span>AdaptIQ - Personalized Learning Management System &copy; 2026</span>
          <span>Powered by Adaptive Item Response Theory & Multi-Factor Recommendation Engines</span>
        </div>
      </footer>
    </div>
  );
}
