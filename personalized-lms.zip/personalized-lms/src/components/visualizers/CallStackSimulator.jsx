import React, { useState } from 'react';
import { Layers, ArrowUp, ArrowDown, RotateCcw, AlertTriangle, CheckCircle2 } from 'lucide-react';

export default function CallStackSimulator() {
  const [n, setN] = useState(4);
  const [stepIndex, setStepIndex] = useState(0);

  // Pre-calculated call stack trace for factorial(4)
  const steps = [
    {
      action: "Initial invocation",
      stack: [
        { call: "factorial(4)", param: 4, phase: "evaluating (4 * factorial(3))", frameId: 4 }
      ],
      currentFrame: 0,
      returnValue: null,
      explanation: "Main thread calls factorial(4). Since 4 > 1, pushes frame and invokes factorial(3)."
    },
    {
      action: "Pushing stack frame",
      stack: [
        { call: "factorial(3)", param: 3, phase: "evaluating (3 * factorial(2))", frameId: 3 },
        { call: "factorial(4)", param: 4, phase: "waiting for child return", frameId: 4 }
      ],
      currentFrame: 0,
      returnValue: null,
      explanation: "Activation record for factorial(3) allocated in thread stack memory."
    },
    {
      action: "Pushing stack frame",
      stack: [
        { call: "factorial(2)", param: 2, phase: "evaluating (2 * factorial(1))", frameId: 2 },
        { call: "factorial(3)", param: 3, phase: "waiting for child return", frameId: 3 },
        { call: "factorial(4)", param: 4, phase: "waiting for child return", frameId: 4 }
      ],
      currentFrame: 0,
      returnValue: null,
      explanation: "Pushed factorial(2). Stack depth is now 3."
    },
    {
      action: "BASE CASE REACHED",
      stack: [
        { call: "factorial(1)", param: 1, phase: "BASE CASE TRIGGERED! Returns 1", frameId: 1, isBase: true },
        { call: "factorial(2)", param: 2, phase: "waiting for child return", frameId: 2 },
        { call: "factorial(3)", param: 3, phase: "waiting for child return", frameId: 3 },
        { call: "factorial(4)", param: 4, phase: "waiting for child return", frameId: 4 }
      ],
      currentFrame: 0,
      returnValue: 1,
      explanation: "🎯 Base Case reached (n == 1)! No further recursive calls made. Frame prepares to return 1."
    },
    {
      action: "Unwinding: Pop factorial(1)",
      stack: [
        { call: "factorial(2)", param: 2, phase: "received 1 -> computes 2 * 1 = 2", frameId: 2 },
        { call: "factorial(3)", param: 3, phase: "waiting for child return", frameId: 3 },
        { call: "factorial(4)", param: 4, phase: "waiting for child return", frameId: 4 }
      ],
      currentFrame: 0,
      returnValue: 2,
      explanation: "factorial(1) returned 1 and was popped. factorial(2) computes (2 * 1 = 2)."
    },
    {
      action: "Unwinding: Pop factorial(2)",
      stack: [
        { call: "factorial(3)", param: 3, phase: "received 2 -> computes 3 * 2 = 6", frameId: 3 },
        { call: "factorial(4)", param: 4, phase: "waiting for child return", frameId: 4 }
      ],
      currentFrame: 0,
      returnValue: 6,
      explanation: "factorial(2) returned 2 and was popped. factorial(3) computes (3 * 2 = 6)."
    },
    {
      action: "Final Unwind: Pop factorial(3)",
      stack: [
        { call: "factorial(4)", param: 4, phase: "received 6 -> computes 4 * 6 = 24", frameId: 4 }
      ],
      currentFrame: 0,
      returnValue: 24,
      explanation: "factorial(3) returned 6. factorial(4) calculates 4 * 6 = 24. Function execution completes!"
    }
  ];

  const current = steps[stepIndex];

  return (
    <div className="visualizer-container">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <div>
          <span className="badge badge-easy" style={{ marginBottom: 4 }}>Call Stack Mechanics</span>
          <h4 style={{ fontSize: '1.1rem', fontWeight: 700 }}>Recursive Call Stack & Base Case Simulator</h4>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
            Simulate how activation records push during recursion and pop during stack unwinding.
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button 
            onClick={() => setStepIndex(0)} 
            className="btn-secondary"
            style={{ padding: '6px 12px', fontSize: '0.8rem' }}
          >
            <RotateCcw size={14} /> Restart Trace
          </button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, margin: '20px 0' }}>
        {/* Memory Call Stack (Visual LIFO stack) */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <span style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-dim)', letterSpacing: '0.05em' }}>
              THREAD CALL STACK (LIFO)
            </span>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
              Depth: {current.stack.length} frames
            </span>
          </div>

          <div 
            style={{
              height: 240,
              background: '#070b14',
              borderRadius: 10,
              border: '2px dashed rgba(255, 255, 255, 0.1)',
              padding: 12,
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'flex-end',
              gap: 8,
              position: 'relative'
            }}
          >
            {current.stack.map((frame, idx) => {
              const isTop = idx === 0;
              return (
                <div
                  key={frame.frameId}
                  style={{
                    padding: '10px 14px',
                    borderRadius: 8,
                    background: frame.isBase 
                      ? 'linear-gradient(135deg, rgba(16, 185, 129, 0.3), rgba(6, 182, 212, 0.3))' 
                      : isTop 
                      ? 'linear-gradient(135deg, rgba(99, 102, 241, 0.35), rgba(79, 70, 229, 0.25))' 
                      : 'rgba(255, 255, 255, 0.04)',
                    border: isTop 
                      ? frame.isBase ? '2px solid #10b981' : '2px solid #6366f1' 
                      : '1px solid rgba(255, 255, 255, 0.08)',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    fontFamily: 'var(--font-mono)',
                    boxShadow: isTop ? '0 0 16px rgba(99, 102, 241, 0.3)' : 'none',
                    transition: 'all 0.3s ease'
                  }}
                >
                  <div>
                    <div style={{ fontWeight: 700, fontSize: '0.9rem', color: '#ffffff' }}>
                      {frame.call}
                      {isTop && (
                        <span style={{ marginLeft: 8, fontSize: '0.7rem', color: '#38bdf8', textTransform: 'uppercase' }}>
                          [ACTIVE FRAME]
                        </span>
                      )}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: 2 }}>
                      {frame.phase}
                    </div>
                  </div>
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>
                    Frame #{frame.frameId}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Code Execution & Diagnostic Box */}
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div 
            style={{ 
              background: '#070b14', 
              borderRadius: 10, 
              padding: 16,
              border: '1px solid var(--border-subtle)',
              fontFamily: 'var(--font-mono)',
              fontSize: '0.82rem',
              lineHeight: 1.6
            }}
          >
            <div style={{ color: 'var(--text-dim)', marginBottom: 6 }}>// Recursive Factorial Implementation</div>
            <div style={{ color: '#c084fc' }}>function factorial(n) {'{'}</div>
            <div style={{ 
              paddingLeft: 16, 
              background: current.returnValue === 1 ? 'rgba(16, 185, 129, 0.2)' : 'transparent',
              borderRadius: 4
            }}>
              <span style={{ color: '#f43f5e' }}>if</span> (n &lt;= 1) <span style={{ color: '#f43f5e' }}>return</span> 1; <span style={{ color: '#10b981' }}>// BASE CASE</span>
            </div>
            <div style={{ 
              paddingLeft: 16,
              background: current.returnValue !== 1 && current.stack.length > 1 ? 'rgba(99, 102, 241, 0.15)' : 'transparent',
              borderRadius: 4
            }}>
              <span style={{ color: '#f43f5e' }}>return</span> n * factorial(n - 1);
            </div>
            <div style={{ color: '#c084fc' }}>{'}'}</div>
          </div>

          <div 
            style={{
              background: 'rgba(255, 255, 255, 0.03)',
              borderRadius: 10,
              padding: 14,
              border: '1px solid var(--border-subtle)',
              marginTop: 12
            }}
          >
            <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>
              STEP {stepIndex + 1} OF {steps.length}: {current.action}
            </div>
            <p style={{ fontSize: '0.85rem', color: '#e2e8f0', marginTop: 4 }}>
              {current.explanation}
            </p>
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <button
          onClick={() => setStepIndex(prev => Math.max(0, prev - 1))}
          disabled={stepIndex === 0}
          className="btn-secondary"
          style={{ opacity: stepIndex === 0 ? 0.5 : 1 }}
        >
          Previous Step
        </button>

        <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
          {stepIndex < 3 ? "Expanding Stack..." : stepIndex === 3 ? "Base Case Evaluated!" : "Unwinding Stack & Returning..."}
        </span>

        <button
          onClick={() => setStepIndex(prev => Math.min(steps.length - 1, prev + 1))}
          disabled={stepIndex === steps.length - 1}
          className="btn-primary"
          style={{ opacity: stepIndex === steps.length - 1 ? 0.5 : 1 }}
        >
          {stepIndex === steps.length - 1 ? "Execution Finished" : "Next Frame Step"}
        </button>
      </div>
    </div>
  );
}
