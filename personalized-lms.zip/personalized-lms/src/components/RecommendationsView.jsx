import React from 'react';
import { 
  Lightbulb, 
  Sparkles, 
  Clock, 
  ArrowRight, 
  Flame, 
  Award, 
  Zap, 
  CheckCircle2, 
  Eye, 
  Code, 
  BookMarked 
} from 'lucide-react';

export default function RecommendationsView({ 
  student, 
  recommendations, 
  onSelectCourse, 
  onStartQuiz, 
  onUpdateLearningStyle 
}) {
  if (!student) return null;

  return (
    <div style={{ maxWidth: 1200, margin: '0 auto', padding: '32px 24px', display: 'flex', flexDirection: 'column', gap: 28 }}>
      
      {/* Header */}
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
          <span className="badge badge-accent">Multi-Factor Engine</span>
          <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>Explainable AI Recommendations</span>
        </div>
        <h2 style={{ fontSize: '1.75rem', fontWeight: 800 }}>Personalized Learning Path Recommendations</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem', marginTop: 4 }}>
          Every suggestion is dynamically derived from your quiz performance, concept gap diagnostics, study velocity, and preferred learning modality.
        </p>
      </div>

      {/* Learning Style Preference Controls */}
      <div className="glass-panel" style={{ padding: 20, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16 }}>
        <div>
          <h4 style={{ fontSize: '0.95rem', fontWeight: 700, color: '#ffffff' }}>Your Current Learning Modality Preference</h4>
          <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: 2 }}>
            The engine biases recommended instructional formats based on your selection.
          </p>
        </div>

        <div style={{ display: 'flex', gap: 8 }}>
          {[
            { id: 'visual', label: 'Visual & Interactive', icon: Eye },
            { id: 'practical', label: 'Hands-on Code', icon: Code },
            { id: 'theoretical', label: 'Theory & Proofs', icon: BookMarked }
          ].map(style => {
            const Icon = style.icon;
            const isActive = student.preferredLearningStyle === style.id;
            return (
              <button
                key={style.id}
                onClick={() => onUpdateLearningStyle(style.id)}
                style={{
                  padding: '8px 14px',
                  borderRadius: 10,
                  fontSize: '0.85rem',
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  background: isActive ? 'var(--accent-primary)' : 'rgba(255, 255, 255, 0.05)',
                  border: isActive ? '1px solid var(--accent-primary)' : '1px solid var(--border-subtle)',
                  color: isActive ? '#ffffff' : 'var(--text-muted)'
                }}
              >
                <Icon size={16} /> {style.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Recommendations Cards Grid */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
        {recommendations && recommendations.length > 0 ? (
          recommendations.map(rec => {
            const isRemedial = rec.type === 'remediation';
            const isAccelerated = rec.type === 'accelerated';
            const isEngagement = rec.type === 'engagement';

            return (
              <div 
                key={rec.id}
                className="glass-panel glass-panel-interactive"
                style={{
                  padding: 24,
                  border: isRemedial 
                    ? '1px solid rgba(244, 63, 94, 0.3)' 
                    : isAccelerated 
                    ? '1px solid rgba(16, 185, 129, 0.3)' 
                    : '1px solid rgba(99, 102, 241, 0.3)',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  flexWrap: 'wrap',
                  gap: 20
                }}
              >
                <div style={{ maxWidth: 750 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                    <span 
                      className={`badge badge-${isRemedial ? 'hard' : isAccelerated ? 'easy' : 'accent'}`}
                    >
                      {rec.badge}
                    </span>
                    <span style={{ fontSize: '0.78rem', color: '#a5b4fc', background: 'rgba(99, 102, 241, 0.1)', padding: '2px 8px', borderRadius: 4 }}>
                      💡 Reasoning: {rec.reason}
                    </span>
                  </div>

                  <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#ffffff' }}>
                    {rec.title}
                  </h3>
                  <p style={{ fontSize: '0.9rem', color: '#cbd5e1', marginTop: 6, lineHeight: 1.5 }}>
                    {rec.description}
                  </p>

                  <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginTop: 12, fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                      <Clock size={14} /> Est. {rec.estimatedMinutes} minutes
                    </span>
                    <span>•</span>
                    <span style={{ color: '#38bdf8' }}>
                      Modality: {rec.modalityMatch}
                    </span>
                  </div>
                </div>

                <div>
                  <button
                    onClick={() => {
                      if (rec.type === 'accelerated') {
                        onStartQuiz(rec.courseId, rec.moduleId);
                      } else {
                        onSelectCourse(rec.courseId, rec.lessonId);
                      }
                    }}
                    className="btn-primary"
                    style={{
                      padding: '12px 24px',
                      background: isRemedial 
                        ? 'linear-gradient(135deg, #f43f5e, #e11d48)' 
                        : isAccelerated 
                        ? 'linear-gradient(135deg, #10b981, #059669)' 
                        : undefined
                    }}
                  >
                    <Zap size={16} /> {rec.actionText}
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="glass-panel" style={{ padding: 40, textAlign: 'center' }}>
            <Sparkles size={32} color="#818cf8" style={{ margin: '0 auto 12px' }} />
            <h4 style={{ fontWeight: 700 }}>Curating Your Adaptive Recommendations...</h4>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginTop: 4 }}>
              Take an adaptive quiz to feed new diagnostic data into the recommendation model.
            </p>
          </div>
        )}
      </div>

    </div>
  );
}
