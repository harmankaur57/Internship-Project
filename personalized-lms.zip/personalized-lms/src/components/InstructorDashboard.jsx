import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Award, 
  Activity, 
  AlertTriangle, 
  Send, 
  PlusCircle, 
  CheckCircle2, 
  Clock, 
  BookOpen, 
  Zap, 
  HelpCircle,
  Eye,
  Filter
} from 'lucide-react';
import StudentModal from './StudentModal.jsx';

export default function InstructorDashboard({ 
  courses, 
  students, 
  activeSubTab = 'cohort', 
  onRefreshData 
}) {
  const [subTab, setSubTab] = useState(activeSubTab === 'curriculum' ? 'curriculum' : 'cohort');
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  
  // Selected student for deep drilldown modal
  const [drilldownStudent, setDrilldownStudent] = useState(null);

  // Intervention modal state
  const [interveneStudent, setInterveneStudent] = useState(null);
  const [interventionNote, setInterventionNote] = useState('');
  const [interventionType, setInterventionType] = useState('Remedial Assignment');

  // New Course Form state
  const [newCourseTitle, setNewCourseTitle] = useState('');
  const [newCourseDesc, setNewCourseDesc] = useState('');
  const [newCourseCategory, setNewCourseCategory] = useState('Computer Science');
  const [newCourseLevel, setNewCourseLevel] = useState('Intermediate');
  const [newCourseHours, setNewCourseHours] = useState(16);

  // New Question Form state
  const [newQCourseId, setNewQCourseId] = useState('cs-101');
  const [newQConcept, setNewQConcept] = useState('recursion-base-case');
  const [newQDifficulty, setNewQDifficulty] = useState('medium');
  const [newQText, setNewQText] = useState('');
  const [newQOpt0, setNewQOpt0] = useState('');
  const [newQOpt1, setNewQOpt1] = useState('');
  const [newQOpt2, setNewQOpt2] = useState('');
  const [newQOpt3, setNewQOpt3] = useState('');
  const [newQCorrect, setNewQCorrect] = useState(0);
  const [newQHint, setNewQHint] = useState('');
  const [newQExplanation, setNewQExplanation] = useState('');
  const [formSuccessMessage, setFormSuccessMessage] = useState('');

  // Fetch instructor analytics
  const fetchAnalytics = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/analytics/instructor');
      const data = await res.json();
      if (data.success) {
        setAnalytics(data);
      }
    } catch (err) {
      console.error('Error fetching instructor analytics:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const handleSendIntervention = async () => {
    if (!interveneStudent) return;
    try {
      const res = await fetch('/api/instructor/intervene', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId: interveneStudent.id,
          interventionType,
          message: interventionNote || `Assigned tailored review modules on ${interveneStudent.weakestConcept || 'core concepts'}.`,
          conceptTag: interveneStudent.weakestConcept || 'recursion-base-case'
        })
      });
      const data = await res.json();
      if (data.success) {
        setInterveneStudent(null);
        setInterventionNote('');
        fetchAnalytics();
        if (onRefreshData) onRefreshData();
      }
    } catch (err) {
      console.error('Error sending intervention:', err);
    }
  };

  const handleCreateCourse = async (e) => {
    e.preventDefault();
    if (!newCourseTitle || !newCourseDesc) return;
    try {
      const res = await fetch('/api/courses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newCourseTitle,
          description: newCourseDesc,
          category: newCourseCategory,
          level: newCourseLevel,
          estimatedHours: newCourseHours
        })
      });
      const data = await res.json();
      if (data.success) {
        setNewCourseTitle('');
        setNewCourseDesc('');
        setFormSuccessMessage('Course created successfully!');
        setTimeout(() => setFormSuccessMessage(''), 4000);
        if (onRefreshData) onRefreshData();
      }
    } catch (err) {
      console.error('Failed to create course:', err);
    }
  };

  const handleCreateQuestion = async (e) => {
    e.preventDefault();
    if (!newQText || !newQOpt0 || !newQOpt1) return;
    try {
      const res = await fetch('/api/questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          courseId: newQCourseId,
          conceptTag: newQConcept,
          difficulty: newQDifficulty,
          question: newQText,
          options: [newQOpt0, newQOpt1, newQOpt2 || 'None of the above', newQOpt3 || 'All of the above'],
          correctIndex: Number(newQCorrect),
          hint: newQHint || 'Review core invariant definitions.',
          explanation: newQExplanation || 'Correct conceptual analysis.'
        })
      });
      const data = await res.json();
      if (data.success) {
        setNewQText('');
        setNewQOpt0('');
        setNewQOpt1('');
        setNewQOpt2('');
        setNewQOpt3('');
        setNewQHint('');
        setNewQExplanation('');
        setFormSuccessMessage('Adaptive question added to assessment bank!');
        setTimeout(() => setFormSuccessMessage(''), 4000);
        fetchAnalytics();
        if (onRefreshData) onRefreshData();
      }
    } catch (err) {
      console.error('Failed to create question:', err);
    }
  };

  const formatConcept = (tag) => {
    if (!tag) return "";
    return tag.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
  };

  return (
    <div style={{ maxWidth: 1350, margin: '0 auto', padding: '32px 24px', display: 'flex', flexDirection: 'column', gap: 28 }}>
      
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span className="badge badge-accent">Instructor Command Center</span>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>Dr. Evelyn Vance (Lead Faculty)</span>
          </div>
          <h2 style={{ fontSize: '1.75rem', fontWeight: 800 }}>Cohort Diagnostics & Curriculum Engine</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginTop: 2 }}>
            Monitor real-time class learning patterns, identify at-risk drop-offs, and curate adaptive item banks.
          </p>
        </div>

        {/* Sub-tab navigation */}
        <div style={{ display: 'flex', gap: 8, background: 'rgba(255, 255, 255, 0.05)', padding: 4, borderRadius: 12 }}>
          <button
            onClick={() => setSubTab('cohort')}
            style={{
              padding: '8px 16px',
              borderRadius: 8,
              fontSize: '0.85rem',
              fontWeight: 600,
              background: subTab === 'cohort' ? 'var(--accent-primary)' : 'transparent',
              color: subTab === 'cohort' ? '#ffffff' : 'var(--text-muted)'
            }}
          >
            Cohort Analytics & Early Warning
          </button>
          <button
            onClick={() => setSubTab('curriculum')}
            style={{
              padding: '8px 16px',
              borderRadius: 8,
              fontSize: '0.85rem',
              fontWeight: 600,
              background: subTab === 'curriculum' ? 'var(--accent-primary)' : 'transparent',
              color: subTab === 'curriculum' ? '#ffffff' : 'var(--text-muted)'
            }}
          >
            Course & Question Bank Manager
          </button>
        </div>
      </div>

      {/* Cohort KPI Summary Cards */}
      {analytics && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 20 }}>
          <div className="glass-panel" style={{ padding: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>
                Total Enrolled Cohort
              </span>
              <Users size={20} color="#818cf8" />
            </div>
            <div style={{ fontSize: '2.2rem', fontWeight: 800, color: '#ffffff', marginTop: 10 }}>
              {analytics.summary.totalStudents}
            </div>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Across 3 core domains</span>
          </div>

          <div className="glass-panel" style={{ padding: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>
                Class Average Mastery
              </span>
              <Award size={20} color="#10b981" />
            </div>
            <div style={{ fontSize: '2.2rem', fontWeight: 800, color: '#10b981', marginTop: 10 }}>
              {analytics.summary.avgMastery}%
            </div>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Adaptive IRT aggregate</span>
          </div>

          <div className="glass-panel" style={{ padding: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>
                Average Engagement
              </span>
              <Activity size={20} color="#38bdf8" />
            </div>
            <div style={{ fontSize: '2.2rem', fontWeight: 800, color: '#38bdf8', marginTop: 10 }}>
              {analytics.summary.avgEngagement}
            </div>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>out of 100 benchmark</span>
          </div>

          <div 
            className="glass-panel" 
            style={{ 
              padding: 20, 
              border: analytics.summary.atRiskCount > 0 ? '1px solid rgba(244, 63, 94, 0.4)' : undefined,
              background: analytics.summary.atRiskCount > 0 ? 'rgba(244, 63, 94, 0.08)' : undefined
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: '0.8rem', color: '#fb7185', fontWeight: 700, textTransform: 'uppercase' }}>
                At-Risk Students Flagged
              </span>
              <AlertTriangle size={20} color="#f43f5e" />
            </div>
            <div style={{ fontSize: '2.2rem', fontWeight: 800, color: '#f43f5e', marginTop: 10 }}>
              {analytics.summary.atRiskCount}
            </div>
            <span style={{ fontSize: '0.8rem', color: '#fb7185' }}>Immediate pedagogical intervention required</span>
          </div>
        </div>
      )}

      {/* SUB-TAB 1: COHORT ANALYTICS & INTERVENTIONS */}
      {subTab === 'cohort' && analytics && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 28 }}>
          
          {/* At-Risk Student Alert Board */}
          <div className="glass-panel" style={{ padding: 28, border: '1px solid rgba(244, 63, 94, 0.3)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
              <AlertTriangle size={22} color="#f43f5e" />
              <div>
                <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#ffffff' }}>
                  Early-Warning Alert: Students at Academic or Drop-off Risk
                </h3>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                  Identified via low quiz accuracy, consecutive difficulty demotions, or inactive study streaks.
                </p>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {analytics.atRiskStudents.map(st => (
                <div
                  key={st.id}
                  style={{
                    background: 'rgba(0, 0, 0, 0.3)',
                    border: '1px solid rgba(244, 63, 94, 0.25)',
                    borderRadius: 12,
                    padding: '16px 20px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    flexWrap: 'wrap',
                    gap: 16
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                    <img 
                      src={st.avatar} 
                      alt={st.name} 
                      style={{ width: 44, height: 44, borderRadius: '50%', objectFit: 'cover' }} 
                    />
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <strong style={{ fontSize: '1rem', color: '#ffffff' }}>{st.name}</strong>
                        <span className="badge badge-hard" style={{ fontSize: '0.65rem' }}>
                          {st.riskFactor}
                        </span>
                      </div>
                      <div style={{ fontSize: '0.8rem', color: 'var(--text-dim)', marginTop: 2 }}>
                        Stumbling Concept: <span style={{ color: '#fb7185', fontWeight: 600 }}>{formatConcept(st.weakestConcept)} ({st.weakestScore}%)</span>
                        {' • '}
                        Streak: {st.streakDays} days
                      </div>
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: 10 }}>
                    <button
                      onClick={() => {
                        const full = students.find(s => s.id === st.id);
                        if (full) setDrilldownStudent(full);
                      }}
                      className="btn-secondary"
                      style={{ padding: '8px 14px', fontSize: '0.82rem' }}
                    >
                      <Eye size={14} /> Inspect Profile
                    </button>
                    <button
                      onClick={() => setInterveneStudent(st)}
                      className="btn-danger"
                      style={{ padding: '8px 16px', fontSize: '0.82rem' }}
                    >
                      <Send size={14} /> Send Intervention
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Class-wide Concept Stumbling Heatmap */}
          <div className="glass-panel" style={{ padding: 28 }}>
            <h3 style={{ fontSize: '1.25rem', fontWeight: 800, marginBottom: 8 }}>
              Curriculum Concept Difficulty Matrix (Class-Wide Heatmap)
            </h3>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: 20 }}>
              Visualizes which concepts are stumbling points across the entire student cohort to inform live lecture interventions.
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 14 }}>
              {analytics.conceptAnalytics.map(item => {
                const isStumbling = item.averageScore < 60;
                const isMastered = item.averageScore >= 80;

                return (
                  <div
                    key={item.concept}
                    style={{
                      background: 'rgba(255, 255, 255, 0.03)',
                      border: isStumbling ? '1px solid rgba(244, 63, 94, 0.3)' : '1px solid var(--border-subtle)',
                      borderRadius: 10,
                      padding: 14
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontWeight: 700, fontSize: '0.85rem', color: '#ffffff' }}>
                        {formatConcept(item.concept)}
                      </span>
                      <span 
                        style={{ 
                          fontWeight: 800, 
                          color: isStumbling ? '#fb7185' : isMastered ? '#34d399' : '#fbbf24' 
                        }}
                      >
                        {item.averageScore}%
                      </span>
                    </div>

                    <div className="progress-track" style={{ height: 6, margin: '8px 0' }}>
                      <div 
                        className="progress-fill" 
                        style={{ 
                          width: `${item.averageScore}%`, 
                          background: isStumbling ? '#f43f5e' : isMastered ? '#10b981' : '#f59e0b' 
                        }} 
                      />
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: 'var(--text-dim)' }}>
                      <span>{item.studentsNeedingHelp} students need help</span>
                      <span className={`badge badge-${isStumbling ? 'hard' : isMastered ? 'easy' : 'medium'}`} style={{ fontSize: '0.6rem' }}>
                        {item.difficultyRating}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* All Students Cohort Roster Table */}
          <div className="glass-panel" style={{ padding: 28 }}>
            <h3 style={{ fontSize: '1.25rem', fontWeight: 800, marginBottom: 16 }}>Class Cohort Roster</h3>
            
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.88rem' }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid var(--border-subtle)', color: 'var(--text-dim)' }}>
                    <th style={{ padding: '12px 16px' }}>Student</th>
                    <th style={{ padding: '12px 16px' }}>Mastery Level</th>
                    <th style={{ padding: '12px 16px' }}>Engagement Score</th>
                    <th style={{ padding: '12px 16px' }}>Learning Modality</th>
                    <th style={{ padding: '12px 16px' }}>Streak</th>
                    <th style={{ padding: '12px 16px', textAlign: 'right' }}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {students.map(st => (
                    <tr key={st.id} style={{ borderBottom: '1px solid rgba(255, 255, 255, 0.05)' }}>
                      <td style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
                        <img src={st.avatar} alt={st.name} style={{ width: 32, height: 32, borderRadius: '50%', objectFit: 'cover' }} />
                        <div>
                          <strong style={{ color: '#ffffff' }}>{st.name}</strong>
                          <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>{st.email}</div>
                        </div>
                      </td>
                      <td style={{ padding: '12px 16px' }}>
                        <span style={{ fontWeight: 700, color: st.overallMastery >= 80 ? '#34d399' : st.overallMastery < 50 ? '#fb7185' : '#fbbf24' }}>
                          {st.overallMastery}%
                        </span>
                      </td>
                      <td style={{ padding: '12px 16px' }}>
                        <span style={{ fontWeight: 700, color: st.engagementScore < 50 ? '#fb7185' : '#38bdf8' }}>
                          {st.engagementScore}/100
                        </span>
                      </td>
                      <td style={{ padding: '12px 16px', textTransform: 'capitalize', color: 'var(--text-muted)' }}>
                        {st.preferredLearningStyle}
                      </td>
                      <td style={{ padding: '12px 16px', color: '#f59e0b', fontWeight: 600 }}>
                        {st.streakDays}d
                      </td>
                      <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                        <button
                          onClick={() => setDrilldownStudent(st)}
                          className="btn-secondary"
                          style={{ padding: '6px 12px', fontSize: '0.78rem' }}
                        >
                          <Eye size={13} /> Deep Dive
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Intervention Logs History */}
          {analytics.interventionsLog && analytics.interventionsLog.length > 0 && (
            <div className="glass-panel" style={{ padding: 24 }}>
              <h4 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: 12 }}>Dispatched Pedagogical Interventions</h4>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {analytics.interventionsLog.map(int => (
                  <div key={int.id} style={{ background: 'rgba(255, 255, 255, 0.03)', padding: '10px 14px', borderRadius: 8, fontSize: '0.82rem', display: 'flex', justifyContent: 'space-between' }}>
                    <span><strong>{int.studentName}</strong>: {int.message}</span>
                    <span style={{ color: 'var(--text-dim)' }}>{new Date(int.timestamp).toLocaleTimeString()}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      )}

      {/* SUB-TAB 2: CURRICULUM & ADAPTIVE QUESTION BANK */}
      {subTab === 'curriculum' && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 28, alignItems: 'start' }}>
          
          {/* Form 1: Add New Adaptive Question */}
          <div className="glass-panel" style={{ padding: 28 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
              <Zap size={20} color="#fbbf24" />
              <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>Add Question to Adaptive Bank</h3>
            </div>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: 20 }}>
              Tag questions with difficulty tiers and granular concepts. The adaptive engine will automatically calibrate item dispatching.
            </p>

            <form onSubmit={handleCreateQuestion} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <div>
                  <label style={{ fontSize: '0.78rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>Target Course</label>
                  <select 
                    value={newQCourseId} 
                    onChange={e => setNewQCourseId(e.target.value)}
                    style={{ width: '100%', marginTop: 4 }}
                  >
                    {courses.map(c => <option key={c.id} value={c.id}>{c.title}</option>)}
                  </select>
                </div>

                <div>
                  <label style={{ fontSize: '0.78rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>Difficulty Tier</label>
                  <select 
                    value={newQDifficulty} 
                    onChange={e => setNewQDifficulty(e.target.value)}
                    style={{ width: '100%', marginTop: 4 }}
                  >
                    <option value="easy">Easy (Foundations)</option>
                    <option value="medium">Medium (Core Application)</option>
                    <option value="hard">Hard (Optimization & Edge Cases)</option>
                  </select>
                </div>
              </div>

              <div>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>Concept Tag</label>
                <select 
                  value={newQConcept} 
                  onChange={e => setNewQConcept(e.target.value)}
                  style={{ width: '100%', marginTop: 4 }}
                >
                  <option value="recursion-base-case">recursion-base-case</option>
                  <option value="call-stack">call-stack</option>
                  <option value="two-pointers">two-pointers</option>
                  <option value="tree-traversal">tree-traversal</option>
                  <option value="memoization-caching">memoization-caching</option>
                  <option value="sliding-window">sliding-window</option>
                  <option value="bst-properties">bst-properties</option>
                </select>
              </div>

              <div>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>Question Prompt</label>
                <textarea 
                  rows={3} 
                  value={newQText} 
                  onChange={e => setNewQText(e.target.value)} 
                  placeholder="e.g. What is the space complexity of Top-Down memoized Fibonacci?"
                  style={{ width: '100%', marginTop: 4 }}
                  required
                />
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>Answer Options</label>
                <input placeholder="Option A (Default choice 0)" value={newQOpt0} onChange={e => setNewQOpt0(e.target.value)} required />
                <input placeholder="Option B (Choice 1)" value={newQOpt1} onChange={e => setNewQOpt1(e.target.value)} required />
                <input placeholder="Option C (Choice 2)" value={newQOpt2} onChange={e => setNewQOpt2(e.target.value)} />
                <input placeholder="Option D (Choice 3)" value={newQOpt3} onChange={e => setNewQOpt3(e.target.value)} />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr', gap: 12 }}>
                <div>
                  <label style={{ fontSize: '0.78rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>Correct Option</label>
                  <select value={newQCorrect} onChange={e => setNewQCorrect(e.target.value)} style={{ width: '100%', marginTop: 4 }}>
                    <option value={0}>Option A</option>
                    <option value={1}>Option B</option>
                    <option value={2}>Option C</option>
                    <option value={3}>Option D</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: '0.78rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>Conceptual Hint</label>
                  <input value={newQHint} onChange={e => setNewQHint(e.target.value)} placeholder="Provides guided reasoning if stuck" style={{ width: '100%', marginTop: 4 }} />
                </div>
              </div>

              <div>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>Pedagogical Explanation</label>
                <input value={newQExplanation} onChange={e => setNewQExplanation(e.target.value)} placeholder="Explains why this answer is correct" style={{ width: '100%', marginTop: 4 }} />
              </div>

              <button type="submit" className="btn-primary" style={{ marginTop: 8 }}>
                <PlusCircle size={16} /> Add Adaptive Question
              </button>
            </form>
          </div>

          {/* Form 2: Author New Course */}
          <div className="glass-panel" style={{ padding: 28 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
              <BookOpen size={20} color="#818cf8" />
              <h3 style={{ fontSize: '1.25rem', fontWeight: 800 }}>Create New Course</h3>
            </div>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: 20 }}>
              Structure new courses, configure modules, and attach prerequisite requirements.
            </p>

            <form onSubmit={handleCreateCourse} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>Course Title</label>
                <input 
                  value={newCourseTitle} 
                  onChange={e => setNewCourseTitle(e.target.value)} 
                  placeholder="e.g. Distributed Systems & Consensus Protocols"
                  style={{ width: '100%', marginTop: 4 }}
                  required
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
                <div>
                  <label style={{ fontSize: '0.78rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>Category</label>
                  <select value={newCourseCategory} onChange={e => setNewCourseCategory(e.target.value)} style={{ width: '100%', marginTop: 4 }}>
                    <option value="Computer Science">Computer Science</option>
                    <option value="Web Development">Web Development</option>
                    <option value="Artificial Intelligence">AI / ML</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: '0.78rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>Level</label>
                  <select value={newCourseLevel} onChange={e => setNewCourseLevel(e.target.value)} style={{ width: '100%', marginTop: 4 }}>
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: '0.78rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>Est. Hours</label>
                  <input type="number" value={newCourseHours} onChange={e => setNewCourseHours(e.target.value)} style={{ width: '100%', marginTop: 4 }} />
                </div>
              </div>

              <div>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>Syllabus Description</label>
                <textarea 
                  rows={4}
                  value={newCourseDesc} 
                  onChange={e => setNewCourseDesc(e.target.value)} 
                  placeholder="Describe the course scope, prerequisites, and learning goals..."
                  style={{ width: '100%', marginTop: 4 }}
                  required
                />
              </div>

              <button type="submit" className="btn-primary" style={{ marginTop: 8 }}>
                <PlusCircle size={16} /> Publish Course Structure
              </button>
            </form>

            {formSuccessMessage && (
              <div style={{ marginTop: 16, padding: '10px 14px', borderRadius: 8, background: 'rgba(16, 185, 129, 0.15)', border: '1px solid rgba(16, 185, 129, 0.3)', color: '#34d399', fontSize: '0.85rem', display: 'flex', alignItems: 'center', gap: 8 }}>
                <CheckCircle2 size={16} /> {formSuccessMessage}
              </div>
            )}
          </div>

        </div>
      )}

      {/* Drilldown Modal */}
      {drilldownStudent && (
        <StudentModal 
          student={drilldownStudent} 
          onClose={() => setDrilldownStudent(null)} 
          onIntervene={(st) => setInterveneStudent(st)} 
        />
      )}

      {/* Intervention Prompt Modal */}
      {interveneStudent && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.7)', zIndex: 1100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div className="glass-panel" style={{ maxWidth: 500, width: '100%', padding: 24 }}>
            <h3 style={{ fontSize: '1.2rem', fontWeight: 800 }}>Dispatch Pedagogical Intervention</h3>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: 4 }}>
              Targeting: <strong>{interveneStudent.name}</strong> (Flagged for {interveneStudent.riskFactor})
            </p>

            <div style={{ margin: '16px 0', display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>Intervention Strategy</label>
                <select value={interventionType} onChange={e => setInterventionType(e.target.value)} style={{ width: '100%', marginTop: 4 }}>
                  <option value="Remedial Assignment">Assign Tailored Remedial Guide</option>
                  <option value="Office Hours Invitation">Invite to 1-on-1 Office Hours</option>
                  <option value="Interactive Simulator">Assign Bite-Sized Visual Simulation</option>
                </select>
              </div>

              <div>
                <label style={{ fontSize: '0.78rem', color: 'var(--text-dim)', fontWeight: 700, textTransform: 'uppercase' }}>Personalized Note / Instructions</label>
                <textarea 
                  rows={3} 
                  value={interventionNote} 
                  onChange={e => setInterventionNote(e.target.value)}
                  placeholder={`Hi ${interveneStudent.name}, let's review ${formatConcept(interveneStudent.weakestConcept)} together...`}
                  style={{ width: '100%', marginTop: 4 }}
                />
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
              <button onClick={() => setInterveneStudent(null)} className="btn-secondary">Cancel</button>
              <button onClick={handleSendIntervention} className="btn-primary">
                <Send size={14} /> Send Intervention
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
