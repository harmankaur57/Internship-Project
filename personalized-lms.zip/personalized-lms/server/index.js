import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { initialCourses, initialQuestions, initialStudents, initialInstructor } from './data.js';
import {
  selectInitialQuestion,
  processAnswerAndPickNext,
  finalizeAdaptiveSession,
  generateRecommendations
} from './adaptiveEngine.js';

const app = express();
const PORT = 5001;

app.use(cors());
app.use(express.json());

// In-memory persistent database store
let courses = JSON.parse(JSON.stringify(initialCourses));
let questions = JSON.parse(JSON.stringify(initialQuestions));
let students = JSON.parse(JSON.stringify(initialStudents));
let instructor = JSON.parse(JSON.stringify(initialInstructor));
let interventionsLog = [];

// ==========================================
// COURSE MANAGEMENT ENDPOINTS
// ==========================================

// GET all courses
app.get('/api/courses', (req, res) => {
  const { studentId } = req.query;
  const student = students.find(s => s.id === studentId);

  const enriched = courses.map(course => {
    let studentProgress = null;
    if (student) {
      const enrollment = student.enrolledCourses.find(e => e.courseId === course.id);
      if (enrollment) {
        studentProgress = enrollment;
      }
    }
    return {
      ...course,
      studentProgress
    };
  });

  res.json({ success: true, courses: enriched });
});

// GET course by ID
app.get('/api/courses/:id', (req, res) => {
  const course = courses.find(c => c.id === req.params.id);
  if (!course) {
    return res.status(404).json({ success: false, message: 'Course not found' });
  }
  res.json({ success: true, course });
});

// POST create course (Instructor)
app.post('/api/courses', (req, res) => {
  const { title, description, category, level, estimatedHours } = req.body;
  if (!title || !description) {
    return res.status(400).json({ success: false, message: 'Title and description required' });
  }

  const newCourse = {
    id: `course-${Date.now()}`,
    title,
    description,
    instructor: instructor.name,
    category: category || 'Computer Science',
    level: level || 'Beginner',
    thumbnail: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=600&auto=format&fit=crop&q=80',
    estimatedHours: Number(estimatedHours) || 12,
    enrolledCount: 0,
    rating: 5.0,
    modules: []
  };

  courses.unshift(newCourse);
  res.status(201).json({ success: true, course: newCourse });
});

// POST add module to course
app.post('/api/courses/:id/modules', (req, res) => {
  const course = courses.find(c => c.id === req.params.id);
  if (!course) {
    return res.status(404).json({ success: false, message: 'Course not found' });
  }

  const { title, duration, concepts } = req.body;
  const newModule = {
    id: `mod-${Date.now()}`,
    title: title || `Module ${course.modules.length + 1}`,
    duration: duration || '3 hours',
    concepts: concepts || ['general-fundamentals'],
    lessons: [
      {
        id: `les-${Date.now()}-1`,
        title: `${title} - Conceptual Overview`,
        type: 'reading',
        duration: '20 min',
        content: `### Welcome to ${title}\nThis module adapts to your learning pace and assessment outcomes.`,
        interactive: false
      }
    ]
  };

  course.modules.push(newModule);
  res.status(201).json({ success: true, module: newModule, course });
});

// ==========================================
// STUDENT PROFILES & PROGRESS TRACKING
// ==========================================

// GET all students
app.get('/api/students', (req, res) => {
  res.json({ success: true, students });
});

// GET student by ID
app.get('/api/students/:id', (req, res) => {
  const student = students.find(s => s.id === req.params.id);
  if (!student) {
    return res.status(404).json({ success: false, message: 'Student not found' });
  }
  res.json({ success: true, student });
});

// PUT update student preferences
app.put('/api/students/:id/preferences', (req, res) => {
  const student = students.find(s => s.id === req.params.id);
  if (!student) {
    return res.status(404).json({ success: false, message: 'Student not found' });
  }

  const { preferredLearningStyle, dailyGoalMinutes } = req.body;
  if (preferredLearningStyle) student.preferredLearningStyle = preferredLearningStyle;
  if (dailyGoalMinutes) student.dailyGoalMinutes = Number(dailyGoalMinutes);

  res.json({ success: true, student });
});

// POST mark lesson completed
app.post('/api/students/:id/lessons/complete', (req, res) => {
  const student = students.find(s => s.id === req.params.id);
  if (!student) return res.status(404).json({ success: false, message: 'Student not found' });

  const { courseId, lessonId, timeSpentMinutes } = req.body;
  let enrollment = student.enrolledCourses.find(e => e.courseId === courseId);
  if (!enrollment) {
    enrollment = {
      courseId,
      progressPercent: 10,
      completedLessonIds: [],
      currentModuleId: 'mod-1',
      quizzesTaken: 0,
      averageQuizScore: 0
    };
    student.enrolledCourses.push(enrollment);
  }

  if (!enrollment.completedLessonIds.includes(lessonId)) {
    enrollment.completedLessonIds.push(lessonId);
  }

  // Update progress calculation
  const targetCourse = courses.find(c => c.id === courseId);
  if (targetCourse) {
    const totalLessons = targetCourse.modules.reduce((acc, m) => acc + m.lessons.length, 0);
    enrollment.progressPercent = Math.min(100, Math.round((enrollment.completedLessonIds.length / totalLessons) * 100));
  }

  // Boost engagement score
  student.engagementScore = Math.min(100, student.engagementScore + 3);
  res.json({ success: true, student, enrollment });
});

// ==========================================
// ADAPTIVE QUIZ ENGINE
// ==========================================

// POST start adaptive quiz session
app.post('/api/quiz/start', (req, res) => {
  const { studentId, courseId, moduleId } = req.body;
  const student = students.find(s => s.id === studentId) || students[0];

  const initial = selectInitialQuestion(questions, student, courseId, moduleId);
  
  res.json({
    success: true,
    initialQuestion: {
      id: initial.question.id,
      courseId: initial.question.courseId,
      moduleId: initial.question.moduleId,
      conceptTag: initial.question.conceptTag,
      difficulty: initial.question.difficulty,
      question: initial.question.question,
      options: initial.question.options,
      hint: initial.question.hint
    },
    currentDifficulty: initial.currentDifficulty,
    totalAvailable: initial.totalAvailable,
    sessionHistory: []
  });
});

// POST submit answer & get next adaptive question
app.post('/api/quiz/answer', (req, res) => {
  const {
    studentId,
    currentQuestionId,
    selectedOptionIndex,
    usedHint,
    timeSpentSeconds,
    sessionHistory,
    courseId
  } = req.body;

  const currentQ = questions.find(q => q.id === currentQuestionId);
  if (!currentQ) {
    return res.status(404).json({ success: false, message: 'Question not found' });
  }

  const student = students.find(s => s.id === studentId) || students[0];
  const courseQuestions = questions.filter(q => q.courseId === (courseId || currentQ.courseId));

  const result = processAnswerAndPickNext({
    currentQuestion: currentQ,
    selectedOptionIndex,
    usedHint,
    timeSpentSeconds,
    sessionHistory: sessionHistory || [],
    questionsPool: courseQuestions,
    student
  });

  // Prepare response without leaking correctIndex of nextQuestion
  const safeNextQuestion = result.nextQuestion ? {
    id: result.nextQuestion.id,
    courseId: result.nextQuestion.courseId,
    moduleId: result.nextQuestion.moduleId,
    conceptTag: result.nextQuestion.conceptTag,
    difficulty: result.nextQuestion.difficulty,
    question: result.nextQuestion.question,
    options: result.nextQuestion.options,
    hint: result.nextQuestion.hint
  } : null;

  res.json({
    success: true,
    isCorrect: result.isCorrect,
    correctIndex: result.correctIndex,
    explanation: result.explanation,
    adaptationReason: result.adaptationReason,
    nextDifficulty: result.nextDifficulty,
    nextQuestion: safeNextQuestion,
    isCompleted: result.isCompleted,
    sessionHistory: result.sessionHistory
  });
});

// POST finalize quiz & persist outcomes
app.post('/api/quiz/complete', (req, res) => {
  const { studentId, courseId, sessionHistory } = req.body;
  const student = students.find(s => s.id === studentId);
  if (!student) {
    return res.status(404).json({ success: false, message: 'Student not found' });
  }

  const courseQuestions = questions.filter(q => q.courseId === courseId);
  const evaluation = finalizeAdaptiveSession({
    sessionHistory,
    questionsPool: courseQuestions,
    student,
    courseId
  });

  // Apply updates to student profile
  student.competencies = evaluation.updatedCompetencies;
  student.overallMastery = evaluation.newOverallMastery;
  student.engagementScore = Math.min(100, student.engagementScore + 5);

  // Update enrollment stats
  const enrollment = student.enrolledCourses.find(e => e.courseId === courseId);
  if (enrollment) {
    enrollment.quizzesTaken += 1;
    enrollment.averageQuizScore = Math.round((enrollment.averageQuizScore * (enrollment.quizzesTaken - 1) + evaluation.percentageScore) / enrollment.quizzesTaken);
  }

  // Record quiz history entry
  const historyEntry = {
    quizId: `attempt-${Date.now()}`,
    courseId,
    timestamp: new Date().toISOString(),
    score: evaluation.percentageScore,
    masteryChange: `${evaluation.percentageScore >= 65 ? '+' : '-'}${Math.abs(evaluation.percentageScore - 65) / 10}%`,
    questionsAnswered: sessionHistory.length,
    difficultyTrajectory: evaluation.difficultyTrajectory,
    weakConceptsIdentified: evaluation.weakConcepts
  };
  student.quizHistory.unshift(historyEntry);

  res.json({
    success: true,
    evaluation,
    student
  });
});

// ==========================================
// RECOMMENDATION ENGINE
// ==========================================

// GET recommendations for student
app.get('/api/recommendations/:studentId', (req, res) => {
  const student = students.find(s => s.id === req.params.studentId);
  if (!student) {
    return res.status(404).json({ success: false, message: 'Student not found' });
  }

  const recommendations = generateRecommendations(student, courses, questions);
  res.json({ success: true, recommendations });
});

// ==========================================
// INSTRUCTOR DASHBOARD & ANALYTICS
// ==========================================

// GET instructor cohort analytics
app.get('/api/analytics/instructor', (req, res) => {
  const totalStudents = students.length;
  const avgMastery = Math.round(students.reduce((acc, s) => acc + s.overallMastery, 0) / totalStudents);
  const avgEngagement = Math.round(students.reduce((acc, s) => acc + s.engagementScore, 0) / totalStudents);

  // Identify at-risk students (engagement < 50 OR mastery < 60)
  const atRiskStudents = students.filter(s => s.engagementScore < 50 || s.overallMastery < 60).map(s => {
    // Find stumbling concept
    const lowest = Object.entries(s.competencies || {}).sort((a, b) => a[1] - b[1])[0];
    return {
      id: s.id,
      name: s.name,
      avatar: s.avatar,
      email: s.email,
      engagementScore: s.engagementScore,
      overallMastery: s.overallMastery,
      riskFactor: s.engagementScore < 50 && s.overallMastery < 60 ? "High Risk: Low Engagement & Mastery" : s.engagementScore < 50 ? "Risk: Disengagement" : "Risk: Academic Stumbling",
      weakestConcept: lowest ? lowest[0] : "general",
      weakestScore: lowest ? lowest[1] : 50,
      streakDays: s.streakDays
    };
  });

  // Calculate concept-wide average mastery across all students
  const allConcepts = [
    "array-indexing", "two-pointers", "sliding-window",
    "recursion-base-case", "call-stack", "divide-and-conquer",
    "tree-traversal", "bst-properties", "tree-balancing",
    "overlapping-subproblems", "memoization-caching", "tabulation"
  ];

  const conceptAnalytics = allConcepts.map(concept => {
    const scores = students.map(s => s.competencies[concept]).filter(v => typeof v === 'number');
    const avg = scores.length > 0 ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 50;
    return {
      concept,
      averageScore: avg,
      difficultyRating: avg < 60 ? 'Hard / Stumbling Point' : avg < 80 ? 'Moderate' : 'Mastered',
      studentsNeedingHelp: students.filter(s => (s.competencies[concept] || 50) < 60).length
    };
  });

  res.json({
    success: true,
    summary: {
      totalStudents,
      avgMastery,
      avgEngagement,
      atRiskCount: atRiskStudents.length,
      totalCourses: courses.length,
      totalQuestions: questions.length
    },
    atRiskStudents,
    conceptAnalytics,
    interventionsLog
  });
});

// POST instructor intervention
app.post('/api/instructor/intervene', (req, res) => {
  const { studentId, interventionType, message, conceptTag } = req.body;
  const student = students.find(s => s.id === studentId);
  if (!student) return res.status(404).json({ success: false, message: 'Student not found' });

  const record = {
    id: `int-${Date.now()}`,
    timestamp: new Date().toISOString(),
    studentId,
    studentName: student.name,
    interventionType: interventionType || 'Remedial Assignment',
    message: message || `Assigned tailored review modules on ${conceptTag}.`,
    conceptTag
  };

  interventionsLog.unshift(record);
  
  // Nudge student engagement
  student.engagementScore = Math.min(100, student.engagementScore + 10);

  res.json({ success: true, intervention: record, student });
});

// ==========================================
// QUESTION BANK MANAGEMENT
// ==========================================

// GET all questions
app.get('/api/questions', (req, res) => {
  res.json({ success: true, questions });
});

// POST add question (Instructor)
app.post('/api/questions', (req, res) => {
  const { courseId, moduleId, conceptTag, difficulty, question, options, correctIndex, hint, explanation } = req.body;
  if (!question || !options || options.length < 2) {
    return res.status(400).json({ success: false, message: 'Invalid question format' });
  }

  const newQ = {
    id: `q-custom-${Date.now()}`,
    courseId: courseId || 'cs-101',
    moduleId: moduleId || 'mod-1',
    conceptTag: conceptTag || 'general-practice',
    difficulty: difficulty || 'medium',
    difficultyWeight: difficulty === 'hard' ? 3 : difficulty === 'medium' ? 2 : 1,
    question,
    options,
    correctIndex: Number(correctIndex) || 0,
    hint: hint || 'Consider basic invariants and edge cases.',
    explanation: explanation || 'Great problem solving!',
    remedialLessonId: 'les-1-1'
  };

  questions.push(newQ);
  res.status(201).json({ success: true, question: newQ });
});

// ==========================================
// RESET STATE
// ==========================================
app.post('/api/reset', (req, res) => {
  courses = JSON.parse(JSON.stringify(initialCourses));
  questions = JSON.parse(JSON.stringify(initialQuestions));
  students = JSON.parse(JSON.stringify(initialStudents));
  instructor = JSON.parse(JSON.stringify(initialInstructor));
  interventionsLog = [];
  res.json({ success: true, message: 'System state reset to initial seed values' });
});

// Static assets & SPA fallback
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const distPath = path.resolve(__dirname, '../dist');

app.use(express.static(distPath));

// Fallback to index.html for client-side routing
app.use((req, res, next) => {
  if (req.method === 'GET' && !req.path.startsWith('/api')) {
    return res.sendFile(path.join(distPath, 'index.html'));
  }
  next();
});

app.listen(PORT, () => {
  console.log(`Adaptive LMS Backend API & Web App running on http://localhost:${PORT}`);
});
